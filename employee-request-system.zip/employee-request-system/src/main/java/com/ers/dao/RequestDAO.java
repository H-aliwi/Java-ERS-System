package com.ers.dao;

import com.ers.entity.Request;
import com.ers.enums.RequestStatus;
import com.ers.enums.RequestType;
import com.ers.util.DatabaseConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DAO for the requests table.
 */
public class RequestDAO {

    private static final Logger logger = LogManager.getLogger(RequestDAO.class);

    private Connection getConnection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    // ================= SAVE =================
    public void save(Request r) {
        String sql = "INSERT INTO requests (employee_id, type, status, title, description, start_date, end_date, amount, created_at, updated_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.NO_GENERATED_KEYS)) {

            stmt.setLong(1, r.getEmployeeId());
            stmt.setObject(2, r.getType(), java.sql.Types.OTHER);
            stmt.setObject(3, r.getStatus(), java.sql.Types.OTHER);
            stmt.setString(4, r.getTitle());
            stmt.setString(5, r.getDescription());
            stmt.setDate(6, r.getStartDate() != null ? Date.valueOf(r.getStartDate()) : null);
            stmt.setDate(7, r.getEndDate() != null ? Date.valueOf(r.getEndDate()) : null);
            stmt.setBigDecimal(8, r.getAmount());
            LocalDateTime now = LocalDateTime.now();
            stmt.setTimestamp(9, Timestamp.valueOf(now));
            stmt.setTimestamp(10, Timestamp.valueOf(now));

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        r.setId(rs.getLong(1));
                    }
                }
            }

            logger.debug("Request saved: {}", r.getTitle());
        } catch (Exception e) {
            logger.error("Error saving request {}: {}", r.getTitle(), e.getMessage(), e);
            throw new RuntimeException("Could not save request", e);
        }
    }

    // ================= UPDATE =================
    public void update(Request r) {
        String sql = "UPDATE requests SET employee_id=?, type=?, status=?, title=?, description=?, " +
                     "start_date=?, end_date=?, amount=?, updated_at=? WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, r.getEmployeeId());
            stmt.setObject(2, r.getType(), java.sql.Types.OTHER);
            stmt.setObject(3, r.getStatus(), java.sql.Types.OTHER);
            stmt.setString(4, r.getTitle());
            stmt.setString(5, r.getDescription());
            stmt.setDate(6, r.getStartDate() != null ? Date.valueOf(r.getStartDate()) : null);
            stmt.setDate(7, r.getEndDate() != null ? Date.valueOf(r.getEndDate()) : null);
            stmt.setBigDecimal(8, r.getAmount());
            stmt.setTimestamp(9, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setLong(10, r.getId());

            int affected = stmt.executeUpdate();
            logger.debug("Request updated: {} (rows: {})", r.getTitle(), affected);

        } catch (Exception e) {
            logger.error("Error updating request {}: {}", r.getTitle(), e.getMessage(), e);
            throw new RuntimeException("Could not update request", e);
        }
    }

    // ================= DELETE =================
    public void delete(Long id) {
        String sql = "DELETE FROM requests WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            int affected = stmt.executeUpdate();
            logger.debug("Request deleted: id={} (rows: {})", id, affected);

        } catch (Exception e) {
            logger.error("Error deleting request id={}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Could not delete request", e);
        }
    }

    // ================= FIND BY ID =================
    public Request findById(Long id) {
        String sql = "SELECT * FROM requests WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRequest(rs);
                }
            }

        } catch (Exception e) {
            logger.error("Error finding request by id={}: {}", id, e.getMessage(), e);
        }

        return null;
    }

    // ================= FIND ALL =================
    public List<Request> findAll() {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM requests ORDER BY created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapRequest(rs));
            }

        } catch (Exception e) {
            logger.error("Error fetching all requests: {}", e.getMessage(), e);
        }

        return list;
    }

    // ================= CUSTOM METHODS =================

    public List<Request> findByEmployee(Long employeeId) {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM requests WHERE employee_id=? ORDER BY created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, employeeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequest(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding requests for employee {}: {}", employeeId, e.getMessage(), e);
        }

        return list;
    }

    public List<Request> findByDepartment(Long departmentId) {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT r.* FROM requests r " +
                     "JOIN users u ON r.employee_id = u.id " +
                     "WHERE u.department_id = ? AND u.is_active = true " +
                     "ORDER BY r.created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, departmentId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequest(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding requests for department {}: {}", departmentId, e.getMessage(), e);
        }

        return list;
    }

    public List<Request> findByStatus(RequestStatus status) {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM requests WHERE status=? ORDER BY created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status.name());
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequest(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding requests by status {}: {}", status, e.getMessage(), e);
        }

        return list;
    }

    public List<Request> findAllWithFilters(RequestType type, RequestStatus status,
                                             LocalDate dateFrom, LocalDate dateTo) {
        List<Request> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM requests WHERE 1=1");
        Map<String, Object> params = new HashMap<>();

        if (type != null) {
            sql.append(" AND type = ?");
            params.put("type", type.name());
        }
        if (status != null) {
            sql.append(" AND status = ?");
            params.put("status", status.name());
        }
        if (dateFrom != null) {
            sql.append(" AND created_at >= ?");
            params.put("dateFrom", Timestamp.valueOf(dateFrom.atStartOfDay()));
        }
        if (dateTo != null) {
            sql.append(" AND created_at <= ?");
            params.put("dateTo", Timestamp.valueOf(dateTo.plusDays(1).atStartOfDay()));
        }
        sql.append(" ORDER BY created_at DESC");

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            int idx = 1;
            if (type != null) stmt.setString(idx++, type.name());
            if (status != null) stmt.setString(idx++, status.name());
            if (dateFrom != null) stmt.setTimestamp(idx++, Timestamp.valueOf(dateFrom.atStartOfDay()));
            if (dateTo != null) stmt.setTimestamp(idx++, Timestamp.valueOf(dateTo.plusDays(1).atStartOfDay()));

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequest(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding requests with filters: {}", e.getMessage(), e);
        }

        return list;
    }

    public List<Request> findRecentByEmployee(Long employeeId) {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT * FROM requests WHERE employee_id=? ORDER BY created_at DESC LIMIT 5";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, employeeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequest(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding recent requests for employee {}: {}", employeeId, e.getMessage(), e);
        }

        return list;
    }

    public List<Request> findRecentByDepartment(Long departmentId) {
        List<Request> list = new ArrayList<>();
        String sql = "SELECT r.* FROM requests r " +
                     "JOIN users u ON r.employee_id = u.id " +
                     "WHERE u.department_id = ? AND u.is_active = true " +
                     "ORDER BY r.created_at DESC LIMIT 5";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, departmentId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequest(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding recent requests for department {}: {}", departmentId, e.getMessage(), e);
        }

        return list;
    }

    public Map<String, Long> countByStatusForEmployee(Long employeeId) {
        Map<String, Long> counts = new HashMap<>();
        String sql = "SELECT status, COUNT(*) FROM requests WHERE employee_id=? GROUP BY status";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, employeeId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    counts.put(rs.getString(1), rs.getLong(2));
                }
            }

        } catch (Exception e) {
            logger.error("Error counting requests by status for employee {}: {}", employeeId, e.getMessage(), e);
        }

        return counts;
    }

    public Map<String, Long> countByStatus() {
        Map<String, Long> counts = new HashMap<>();
        String sql = "SELECT status, COUNT(*) FROM requests GROUP BY status";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                counts.put(rs.getString(1), rs.getLong(2));
            }

        } catch (Exception e) {
            logger.error("Error counting requests by status: {}", e.getMessage(), e);
        }

        return counts;
    }

    public Map<String, Long> countByType() {
        Map<String, Long> counts = new HashMap<>();
        String sql = "SELECT type, COUNT(*) FROM requests GROUP BY type";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                counts.put(rs.getString(1), rs.getLong(2));
            }

        } catch (Exception e) {
            logger.error("Error counting requests by type: {}", e.getMessage(), e);
        }

        return counts;
    }

    // ================= HELPER =================
    private Request mapRequest(ResultSet rs) throws SQLException {
        Request r = new Request();
        r.setId(rs.getLong("id"));
        r.setEmployeeId(rs.getLong("employee_id"));
        r.setType(RequestType.valueOf(rs.getString("type")));
        r.setStatus(RequestStatus.valueOf(rs.getString("status")));
        r.setTitle(rs.getString("title"));
        r.setDescription(rs.getString("description"));
        r.setStartDate(rs.getDate("start_date") != null ? rs.getDate("start_date").toLocalDate() : null);
        r.setEndDate(rs.getDate("end_date") != null ? rs.getDate("end_date").toLocalDate() : null);
        r.setAmount(rs.getBigDecimal("amount"));
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) r.setCreatedAt(createdAt.toLocalDateTime());
        Timestamp updatedAt = rs.getTimestamp("updated_at");
        if (updatedAt != null) r.setUpdatedAt(updatedAt.toLocalDateTime());
        return r;
    }
}
