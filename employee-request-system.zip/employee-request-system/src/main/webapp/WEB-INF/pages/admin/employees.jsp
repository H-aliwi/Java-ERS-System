<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<%-- This JSP is inserted into layout.jsp via Tiles as the "content" attribute --%>

<!-- Page Header -->
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
    <div>
        <h2 style="font-size:20px; color:#1a1a2e;">Employees</h2>
        <p style="color:#888; font-size:13px; margin-top:3px;">
            Total: <strong>${totalCount}</strong> active employees
        </p>
    </div>
    <a href="${pageContext.request.contextPath}/addEmployee" class="btn btn-primary">
        &#43; Add Employee
    </a>
</div>

<%-- Success / error messages from action --%>
<s:if test="hasActionMessages()">
    <div class="alert alert-success"><s:actionmessage/></div>
</s:if>
<s:if test="hasActionErrors()">
    <div class="alert alert-error"><s:actionerror/></div>
</s:if>

<!-- Search Bar -->
<div class="card" style="padding:16px 20px; margin-bottom:16px;">
    <s:form action="employees" method="get" theme="simple" cssClass="search-bar">
        <s:textfield name="searchKeyword" value="%{searchKeyword}"
                     placeholder="Search by name or username..." cssStyle="max-width:300px;"/>
        <button type="submit" class="btn btn-secondary">Search</button>
        <c:if test="${not empty searchKeyword}">
            <a href="${pageContext.request.contextPath}/employees" class="btn btn-secondary">Clear</a>
        </c:if>
    </s:form>
</div>

<!-- Employee Table -->
<div class="card">
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty employees}">
                        <tr>
                            <td colspan="9" style="text-align:center; color:#888; padding:30px;">
                                No employees found.
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="emp" items="${employees}" varStatus="status">
                            <tr>
                                <td style="color:#888;">${(currentPage - 1) * 10 + status.index + 1}</td>
                                <td><strong>${emp.fullName}</strong></td>
                                <td style="color:#555;">${emp.username}</td>
                                <td>${emp.email}</td>
                                <td>${empty emp.phone ? '—' : emp.phone}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${emp.role == 'ADMIN'}">
                                            <span class="badge badge-admin">Admin</span>
                                        </c:when>
                                        <c:when test="${emp.role == 'MANAGER'}">
                                            <span class="badge badge-manager">Manager</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-employee">Employee</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${empty emp.departmentId ? '—' : emp.departmentId}</td>
                                <td>${emp.createdAt}</td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/editEmployee?id=${emp.id}"
                                       class="btn btn-warning btn-sm">Edit</a>
                                    <a href="${pageContext.request.contextPath}/deleteEmployee?id=${emp.id}"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Deactivate ${emp.fullName}?')">Delete</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>

    <%-- Pagination — only shown when not in search mode --%>
    <c:if test="${empty searchKeyword && totalPages > 1}">
        <div class="pagination">
            <c:if test="${currentPage > 1}">
                <a href="?currentPage=${currentPage - 1}">&laquo; Prev</a>
            </c:if>

            <c:forEach begin="1" end="${totalPages}" var="p">
                <c:choose>
                    <c:when test="${p == currentPage}">
                        <span class="active">${p}</span>
                    </c:when>
                    <c:otherwise>
                        <a href="?currentPage=${p}">${p}</a>
                    </c:otherwise>
                </c:choose>
            </c:forEach>

            <c:if test="${currentPage < totalPages}">
                <a href="?currentPage=${currentPage + 1}">Next &raquo;</a>
            </c:if>
        </div>
    </c:if>

</div>
