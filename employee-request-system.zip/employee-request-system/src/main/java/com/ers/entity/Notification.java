package com.ers.entity;

import java.time.LocalDateTime;

/**
 * Plain POJO representing a row in the "notifications" table.
 * No JPA/Hibernate annotations — mapped manually in NotificationDAO.
 */
public class Notification {

    private Long id;
    private Long userId;
    private String message;
    private boolean isRead = false;
    private LocalDateTime createdAt;

    // --- Constructors ---

    public Notification() {}

    public Notification(Long userId, String message) {
        this.userId = userId;
        this.message = message;
    }

    // --- Getters and Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }

    // Alias getter for JSON serialization (getRead() for 'read' field)
    public boolean getRead() { return isRead; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
