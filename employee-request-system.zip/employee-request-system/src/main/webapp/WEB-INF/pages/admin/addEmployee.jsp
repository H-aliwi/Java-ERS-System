<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s"   uri="/struts-tags" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<div style="max-width:760px;">

    <!-- Page Header -->
    <div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
        <a href="${pageContext.request.contextPath}/employees"
           class="btn btn-secondary btn-sm">&#8592; Back</a>
        <h2 style="font-size:20px; color:#1a1a2e;">Add New Employee</h2>
    </div>

    <%-- Server-side errors --%>
    <s:if test="hasActionErrors()">
        <div class="alert alert-error"><s:actionerror/></div>
    </s:if>

    <div class="card">
        <%--
            action="saveEmployee" → maps to EmployeeAction.save() in struts.xml
            theme="simple"       → Struts renders only the input tag, no extra HTML wrappers
        --%>
        <s:form action="saveEmployee" method="post" theme="simple" id="addForm">

            <div class="form-grid">

                <!-- Full Name -->
                <div class="form-group">
                    <label>Full Name <span class="required">*</span></label>
                    <s:textfield name="employee.fullName" id="fullName" maxlength="100"
                                 placeholder="e.g. John Smith"/>
                    <s:fielderror fieldName="employee.fullName" cssClass="field-error-msg"/>
                </div>

                <!-- Username -->
                <div class="form-group">
                    <label>Username <span class="required">*</span></label>
                    <s:textfield name="employee.username" id="username" maxlength="50"
                                 placeholder="e.g. jsmith"/>
                    <s:fielderror fieldName="employee.username" cssClass="field-error-msg"/>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label>Email <span class="required">*</span></label>
                    <s:textfield name="employee.email" id="email" maxlength="100"
                                 placeholder="e.g. john@company.com"/>
                    <s:fielderror fieldName="employee.email" cssClass="field-error-msg"/>
                </div>

                <!-- Phone -->
                <div class="form-group">
                    <label>Phone</label>
                    <s:textfield name="employee.phone" id="phone" maxlength="20"
                                 placeholder="e.g. 39001234"/>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label>Password <span class="required">*</span></label>
                    <s:password name="employee.password" id="password" maxlength="100"
                                placeholder="Minimum 6 characters"/>
                    <s:fielderror fieldName="employee.password" cssClass="field-error-msg"/>
                </div>

                <!-- Role -->
                <div class="form-group">
                    <label>Role <span class="required">*</span></label>
                    <s:select name="employee.role" id="role"
                              list="roles" listKey="name()" listValue="name()"
                              headerKey="" headerValue="-- Select Role --"/>
                    <s:fielderror fieldName="employee.role" cssClass="field-error-msg"/>
                </div>

                <!-- Department -->
                <div class="form-group">
                    <label>Department</label>
                    <s:select name="employee.departmentId" id="departmentId"
                              list="departments" listKey="id" listValue="name"
                              headerKey="" headerValue="-- No Department --"/>
                </div>

            </div>

            <div style="display:flex; gap:10px; margin-top:8px;">
                <button type="submit" class="btn btn-primary" onclick="return validateAddForm()">
                    Save Employee
                </button>
                <a href="${pageContext.request.contextPath}/employees" class="btn btn-secondary">
                    Cancel
                </a>
            </div>

        </s:form>
    </div>
</div>

<script>
    function validateAddForm() {
        let valid = true;

        const fields = [
            { id: 'fullName', msg: 'Full name is required.' },
            { id: 'username', msg: 'Username is required.' },
            { id: 'email',    msg: 'Email is required.' },
            { id: 'password', msg: 'Password is required.' },
            { id: 'role',     msg: 'Role is required.' }
        ];

        // Clear previous client errors
        document.querySelectorAll('.client-error').forEach(el => el.remove());

        fields.forEach(f => {
            const el = document.getElementById(f.id);
            if (!el || !el.value.trim()) {
                const err = document.createElement('div');
                err.className = 'field-error-msg client-error';
                err.textContent = f.msg;
                el.parentNode.appendChild(err);
                valid = false;
            }
        });

        // Email format check
        const email = document.getElementById('email');
        if (email && email.value.trim()) {
            const emailRegex = /^[\w._%+\-]+@[\w.\-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email.value.trim())) {
                const err = document.createElement('div');
                err.className = 'field-error-msg client-error';
                err.textContent = 'Please enter a valid email address.';
                email.parentNode.appendChild(err);
                valid = false;
            }
        }

        // Password length check
        const pwd = document.getElementById('password');
        if (pwd && pwd.value.trim() && pwd.value.trim().length < 6) {
            const err = document.createElement('div');
            err.className = 'field-error-msg client-error';
            err.textContent = 'Password must be at least 6 characters.';
            pwd.parentNode.appendChild(err);
            valid = false;
        }

        return valid;
    }
</script>
