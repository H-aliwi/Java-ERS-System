package com.ers.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * JDBC connection manager.
 * Provides database connections using DriverManager.
 * In a production environment, consider using a connection pool (HikariCP).
 */
public class DatabaseConnection {

    private static final Logger logger = LogManager.getLogger(DatabaseConnection.class);

    private static final String URL = "jdbc:postgresql://localhost:5432/ers_db";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "root";

    static {
        try {
            // Load PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");
            logger.info("PostgreSQL JDBC driver loaded successfully.");
        } catch (ClassNotFoundException e) {
            logger.error("Failed to load PostgreSQL JDBC driver.", e);
            throw new ExceptionInInitializerError(e);
        }
    }

    /**
     * Returns a new database connection.
     * Caller is responsible for closing the connection.
     *
     * @return a fresh Connection instance
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
