package com.ers.service;

import com.ers.dao.DepartmentDAO;
import com.ers.dao.UserDAO;
import com.ers.entity.Department;
import com.ers.entity.User;
import com.ers.enums.Role;
import com.ers.util.PasswordUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class UserService {

    private static final Logger logger = LogManager.getLogger(UserService.class);

    private final UserDAO userDAO = new UserDAO();
    private final DepartmentDAO departmentDAO = new DepartmentDAO();

    // ================= GET ALL =================
    public List<User> getAllEmployees() {
        return userDAO.findAllActive();
    }
    
 // ================= GET ALL (PAGINATED) =================
    private static final int PAGE_SIZE = 10;
    private int  totalPages;
    private long totalEmployeeCount;

    public List<User> getAllEmployees(int page) {
        List<User> all = userDAO.findAllActive();
        totalEmployeeCount = all.size();
        totalPages = (int) Math.ceil((double) totalEmployeeCount / PAGE_SIZE);
        if (totalPages == 0) totalPages = 1;
        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;
        int from = (page - 1) * PAGE_SIZE;
        int to   = Math.min(from + PAGE_SIZE, all.size());
        return all.subList(from, to);
    }

    public int  getTotalPages()         { return totalPages; }
    public long getTotalEmployeeCount() { return totalEmployeeCount; }

    // ================= SEARCH EMPLOYEES =================
    public List<User> searchEmployees(String keyword) {
        String lower = keyword.toLowerCase();
        return userDAO.findAllActive().stream()
                .filter(u ->
                    (u.getFullName() != null && u.getFullName().toLowerCase().contains(lower)) ||
                    (u.getUsername() != null && u.getUsername().toLowerCase().contains(lower))
                )
                .collect(java.util.stream.Collectors.toList());
    }

    // ================= GET BY ID =================
    public User getEmployeeById(Long id) {
        return userDAO.findById(id);
    }
    
    

    // ================= CREATE =================
    public void createEmployee(User user) {

        if (userDAO.usernameExists(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }

        user.setPassword(PasswordUtil.hash(user.getPassword()));
        user.setActive(true);

        userDAO.save(user);

        logger.info("Employee created: {}", user.getUsername());
    }

    // ================= UPDATE =================
    public void updateEmployee(User user, String newPassword, String existingHash) {

        if (newPassword != null && !newPassword.trim().isEmpty()) {
            user.setPassword(PasswordUtil.hash(newPassword));
        } else {
            user.setPassword(existingHash);
        }

        userDAO.update(user);

        logger.info("Employee updated: id={}", user.getId());
    }

    // ================= DELETE (SOFT DELETE) =================
    public void deleteEmployee(Long id) {
        userDAO.deactivate(id);
        logger.info("Employee deactivated: id={}", id);
    }

    // ================= SEARCH BY USERNAME =================
    public User searchByUsername(String username) {
        return userDAO.findByUsername(username);
    }

    // ================= FILTER BY ROLE =================
    public List<User> getManagers() {
        return userDAO.findByRole(Role.MANAGER);
    }

    // ================= DEPARTMENTS =================
    public List<Department> getDepartments() {
        return departmentDAO.findAll();
    }
}