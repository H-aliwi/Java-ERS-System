package com.ers.entity;

import com.ers.enums.Role;
import java.time.LocalDateTime;

/**
 * Plain POJO representing a row in the "users" table.
 * No JPA/Hibernate annotations — mapped manually in UserDAO.
 */
public class User {

    private Long id;
    private String username;
    private String password;
    private String fullName;
    private String email;
    private String phone;
    private Role role;
    private Long departmentId;
    private LocalDateTime createdAt;
    private boolean active = true;

    // --- Constructors ---

    public User() {}

    // --- Getters and Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
