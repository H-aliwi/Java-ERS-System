<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s"   uri="/struts-tags" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
    <h2 style="font-size:20px; color:#1a1a2e;">Department Requests</h2>
    <span style="color:#888; font-size:13px;">${requests.size()} total requests</span>
</div>

<s:if test="hasActionMessages()">
    <div class="alert alert-success"><s:actionmessage/></div>
</s:if>
<s:if test="hasActionErrors()">
    <div class="alert alert-error"><s:actionerror/></div>
</s:if>

<div class="card">
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Employee ID</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty requests}">
                        <tr>
                            <td colspan="7" style="text-align:center; color:#888; padding:30px;">
                                No requests found in your department.
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="req" items="${requests}" varStatus="st">
                            <tr>
                                <td style="color:#888;">${st.index + 1}</td>
                                <td>#${req.employeeId}</td>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/reviewRequest?id=${req.id}"
                                       class="btn btn-primary btn-sm">Review</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
