package com.ers.util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Utility class for password hashing and verification using BCrypt.
 *
 * Why BCrypt?
 * - Automatically salts the hash (each hash is unique even for same password)
 * - Computationally slow by design — resists brute-force attacks
 * - Industry standard for password storage
 *
 * Never store or compare plain-text passwords anywhere in the system.
 */
public class PasswordUtil {

    // Work factor: 10 is the recommended default (higher = slower = more secure)
    private static final int WORK_FACTOR = 10;

    private PasswordUtil() {}

    /**
     * Hashes a plain-text password using BCrypt.
     * Call this when creating or updating a user's password.
     *
     * @param plainPassword the raw password entered by the user
     * @return a BCrypt hash string (60 characters)
     */
    public static String hash(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(WORK_FACTOR));
    }

    /**
     * Verifies a plain-text password against a stored BCrypt hash.
     * Call this during login to check the entered password.
     *
     * @param plainPassword  the raw password entered at login
     * @param hashedPassword the BCrypt hash stored in the database
     * @return true if the password matches, false otherwise
     */
    public static boolean verify(String plainPassword, String hashedPassword) {
        if (plainPassword == null || hashedPassword == null) return false;
        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
}
