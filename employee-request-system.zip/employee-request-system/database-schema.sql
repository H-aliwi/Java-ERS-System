-- ============================================================
-- Employee Request Management System — Database Schema
-- Database: PostgreSQL
-- Run this script once before starting the application.
-- ============================================================

-- Create the database (run this separately if needed)
-- CREATE DATABASE ers_db;

-- Connect to ers_db before running the rest:
-- \c ers_db

-- ============================================================
-- DROP existing tables (safe re-run order: children first)
-- ============================================================
DROP TABLE IF EXISTS notifications    CASCADE;
DROP TABLE IF EXISTS request_actions  CASCADE;
DROP TABLE IF EXISTS requests         CASCADE;
DROP TABLE IF EXISTS users            CASCADE;
DROP TABLE IF EXISTS departments      CASCADE;

-- ============================================================
-- ENUM TYPES
-- ============================================================
DROP TYPE IF EXISTS user_role       CASCADE;
DROP TYPE IF EXISTS request_type    CASCADE;
DROP TYPE IF EXISTS request_status  CASCADE;
DROP TYPE IF EXISTS action_type     CASCADE;

CREATE TYPE user_role      AS ENUM ('ADMIN', 'MANAGER', 'EMPLOYEE');
CREATE TYPE request_type   AS ENUM ('LEAVE', 'LOAN', 'TRAINING');
CREATE TYPE request_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'CANCELLED');
CREATE TYPE action_type    AS ENUM ('APPROVED', 'REJECTED', 'CANCELLED');

-- ============================================================
-- TABLE: departments
-- Created before users because users.department_id references it.
-- ============================================================
CREATE TABLE departments (
    id          BIGSERIAL       PRIMARY KEY,
    name        VARCHAR(100)    NOT NULL UNIQUE,
    description VARCHAR(255),
    manager_id  BIGINT          -- FK to users.id, set after users are inserted
);

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE users (
    id            BIGSERIAL       PRIMARY KEY,
    username      VARCHAR(50)     NOT NULL UNIQUE,
    password      VARCHAR(255)    NOT NULL,   -- BCrypt hash
    full_name     VARCHAR(100)    NOT NULL,
    email         VARCHAR(100)    NOT NULL UNIQUE,
    phone         VARCHAR(20),
    role          user_role       NOT NULL,
    department_id BIGINT          REFERENCES departments(id) ON DELETE SET NULL,
    created_at    TIMESTAMP       NOT NULL DEFAULT NOW(),
    is_active     BOOLEAN         NOT NULL DEFAULT TRUE
);

-- Indexes for fast login and department-based queries
CREATE INDEX idx_users_username   ON users(username);
CREATE INDEX idx_users_department ON users(department_id);
CREATE INDEX idx_users_role       ON users(role);

-- ============================================================
-- TABLE: requests
-- ============================================================
CREATE TABLE requests (
    id          BIGSERIAL       PRIMARY KEY,
    employee_id BIGINT          NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        request_type    NOT NULL,
    status      request_status  NOT NULL DEFAULT 'PENDING',
    title       VARCHAR(150)    NOT NULL,
    description TEXT,
    start_date  DATE,
    end_date    DATE,
    amount      NUMERIC(12, 2), -- Only for LOAN requests
    created_at  TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMP       NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_requests_employee ON requests(employee_id);
CREATE INDEX idx_requests_status   ON requests(status);
CREATE INDEX idx_requests_type     ON requests(type);
CREATE INDEX idx_requests_created  ON requests(created_at DESC);

-- ============================================================
-- TABLE: request_actions (audit trail)
-- ============================================================
CREATE TABLE request_actions (
    id          BIGSERIAL       PRIMARY KEY,
    request_id  BIGINT          NOT NULL REFERENCES requests(id) ON DELETE CASCADE,
    action_by   BIGINT          NOT NULL REFERENCES users(id),
    action      action_type     NOT NULL,
    comment     VARCHAR(500),
    action_date TIMESTAMP       NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_actions_request ON request_actions(request_id);

-- ============================================================
-- TABLE: notifications
-- ============================================================
CREATE TABLE notifications (
    id         BIGSERIAL    PRIMARY KEY,
    user_id    BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    message    VARCHAR(500) NOT NULL,
    is_read    BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user   ON notifications(user_id);
CREATE INDEX idx_notifications_unread ON notifications(user_id, is_read);

-- ============================================================
-- FK: departments.manager_id → users.id
-- Added after both tables exist.
-- ============================================================
ALTER TABLE departments
    ADD CONSTRAINT fk_dept_manager
    FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL;

-- ============================================================
-- SAMPLE DATA
-- Passwords are BCrypt hashes of the values shown in comments.
-- Use PasswordUtil.hash() to generate new hashes.
--
-- admin1    → password: admin123
-- admin2    → password: admin456
-- manager1  → password: manager123
-- manager2  → password: manager456
-- manager3  → password: manager789
-- emp1..5   → password: emp123
-- ============================================================

-- Departments (manager_id set after users are inserted)
INSERT INTO departments (name, description) VALUES
    ('Engineering',  'Software development and infrastructure'),
    ('Human Resources', 'HR and employee relations');

-- Admins (no department)
INSERT INTO users (username, password, full_name, email, phone, role, department_id) VALUES
    ('admin1', '$2a$12$sIba0/9zetmeuYvWk43S9OiTuE3d7NoDrk6rpOc9m6QmNgKeRPBlu',
     'Alice Admin', 'alice@ers.com', '39001001', 'ADMIN', NULL),
    ('admin2', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'Bob Admin',   'bob@ers.com',   '39001002', 'ADMIN', NULL);

-- Managers
INSERT INTO users (username, password, full_name, email, phone, role, department_id) VALUES
    ('manager1', '$2a$12$ItAMoO61FPitNQA9/FgEtuKweQIqPF8WTXj8SYOPCPfpq9UWgaMlm',
     'Carol Manager', 'carol@ers.com', '39002001', 'MANAGER', 1),
    ('manager2', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'David Manager', 'david@ers.com', '39002002', 'MANAGER', 2),
    ('manager3', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'Eve Manager',   'eve@ers.com',   '39002003', 'MANAGER', 1);

-- Employees
INSERT INTO users (username, password, full_name, email, phone, role, department_id) VALUES
    ('emp1', '$2a$12$v1wzNa5KOvOA8CBCtsMO1uvOKRWqPcrEVBV1z.VdC4FMH1qGV7Ezq',
     'Frank Employee', 'frank@ers.com', '39003001', 'EMPLOYEE', 1),
    ('emp2', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'Grace Employee', 'grace@ers.com', '39003002', 'EMPLOYEE', 1),
    ('emp3', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'Henry Employee', 'henry@ers.com', '39003003', 'EMPLOYEE', 2),
    ('emp4', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'Iris Employee',  'iris@ers.com',  '39003004', 'EMPLOYEE', 2),
    ('emp5', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LPVyNkdnzSi',
     'Jack Employee',  'jack@ers.com',  '39003005', 'EMPLOYEE', 1);

-- Assign managers to departments
-- Engineering → manager1 (id=3), HR → manager2 (id=4)
UPDATE departments SET manager_id = 3 WHERE id = 1;
UPDATE departments SET manager_id = 4 WHERE id = 2;

-- Sample requests (employee IDs: emp1=6, emp2=7, emp3=8, emp4=9, emp5=10)
INSERT INTO requests (employee_id, type, status, title, description, start_date, end_date, amount) VALUES
    (6,  'LEAVE',    'PENDING',  'Annual Leave Request',
     'Requesting 5 days of annual leave for family vacation.',
     '2025-08-01', '2025-08-05', NULL),

    (7,  'LOAN',     'APPROVED', 'Personal Loan Request',
     'Requesting a personal loan for home renovation.',
     NULL, NULL, 2000.00),

    (8,  'TRAINING', 'PENDING',  'Java Spring Boot Training',
     'Requesting approval to attend a 3-day Spring Boot workshop.',
     '2025-07-20', '2025-07-22', NULL),

    (9, 'LEAVE',    'REJECTED', 'Sick Leave',
     'Requesting sick leave due to medical appointment.',
     '2025-07-10', '2025-07-11', NULL),

    (10, 'LOAN',     'PENDING',  'Emergency Loan',
     'Requesting emergency loan for urgent medical expenses.',
     NULL, NULL, 500.00);

-- Sample request actions (for the APPROVED and REJECTED requests)
INSERT INTO request_actions (request_id, action_by, action, comment) VALUES
    (2, 4, 'APPROVED', 'Loan approved after reviewing employee record.'),
    (4, 4, 'REJECTED', 'Insufficient sick leave balance.');

-- ============================================================
-- Verify
-- ============================================================
SELECT 'departments' AS tbl, COUNT(*) FROM departments
UNION ALL SELECT 'users',           COUNT(*) FROM users
UNION ALL SELECT 'requests',        COUNT(*) FROM requests
UNION ALL SELECT 'request_actions', COUNT(*) FROM request_actions;
