package com.ers.enums;

/**
 * Represents the three roles a user can have in the system.
 * Stored as a STRING in the database (not ordinal) for readability.
 * Used in: User entity, AuthInterceptor, JSP role checks.
 */
public enum Role {
    ADMIN,
    MANAGER,
    EMPLOYEE
}
