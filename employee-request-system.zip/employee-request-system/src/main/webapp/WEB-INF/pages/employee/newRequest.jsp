<%@ page contentType="text/html;charset=UTF-8" %> <%@ taglib prefix="s"
uri="/struts-tags" %> <%@ taglib prefix="c"
uri="http://java.sun.com/jsp/jstl/core" %>

<div style="max-width: 680px">
  <div
    style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px"
  >
    <a
      href="${pageContext.request.contextPath}/myRequests"
      class="btn btn-secondary btn-sm"
      >&#8592; Back</a
    >
    <h2 style="font-size: 20px; color: #1a1a2e">New Request</h2>
  </div>

  <s:if test="hasActionErrors()">
    <div class="alert alert-error"><s:actionerror /></div>
  </s:if>

  <div class="card">
    <s:form
      action="submitRequest"
      method="post"
      theme="simple"
      id="newRequestForm"
    >
      <!-- Request Type -->
      <div class="form-group">
        <label>Request Type <span class="required">*</span></label>
        <s:select
          name="type"
          id="requestType"
          list="requestTypes"
          listKey="name()"
          listValue="name()"
          headerKey=""
          headerValue="-- Select Type --"
          onchange="toggleFields(this.value)"
        />
        <s:fielderror fieldName="type" cssClass="field-error-msg" />
      </div>

      <!-- Title -->
      <div class="form-group">
        <label>Title <span class="required">*</span></label>
        <s:textfield
          name="title"
          id="title"
          maxlength="150"
          placeholder="Brief title for your request"
        />
        <s:fielderror fieldName="title" cssClass="field-error-msg" />
      </div>

      <!-- Description -->
      <div class="form-group">
        <label>Description</label>
        <s:textarea
          name="description"
          rows="3"
          placeholder="Provide details about your request..."
        />
      </div>

      <!-- Date fields — shown for LEAVE and TRAINING -->
      <div id="dateFields" style="display: none">
        <div class="form-grid">
          <div class="form-group">
            <label>Start Date <span class="required">*</span></label>
            <s:textfield name="startDate" id="startDate" type="date" />
            <s:fielderror fieldName="startDate" cssClass="field-error-msg" />
          </div>
          <div class="form-group">
            <label>End Date <span class="required">*</span></label>
            <s:textfield name="endDate" id="endDate" type="date" />
            <s:fielderror fieldName="endDate" cssClass="field-error-msg" />
          </div>
        </div>
      </div>

      <!-- Amount field — shown for LOAN -->
      <div id="amountField" style="display: none">
        <div class="form-group">
          <label>Loan Amount (BHD) <span class="required">*</span></label>
          <s:textfield
            name="amount"
            id="amount"
            type="number"
            placeholder="e.g. 500.00"
            step="0.01"
            min="1"
          />
          <s:fielderror fieldName="amount" cssClass="field-error-msg" />
        </div>
      </div>

      <div style="display: flex; gap: 10px; margin-top: 8px">
        <button type="submit" class="btn btn-primary">Submit Request</button>
        <a
          href="${pageContext.request.contextPath}/myRequests"
          class="btn btn-secondary"
        >
          Cancel
        </a>
      </div>
    </s:form>
  </div>
</div>

<script>
  function toggleFields(type) {
    document.getElementById("dateFields").style.display =
      type === "LEAVE" || type === "TRAINING" ? "block" : "none"
    document.getElementById("amountField").style.display =
      type === "LOAN" ? "block" : "none"
  }

  // Restore field visibility if form was re-shown after a validation error
  const selectedType = document.getElementById("requestType").value
  if (selectedType) toggleFields(selectedType)
</script>
