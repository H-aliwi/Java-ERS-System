<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<h2 style="font-size:20px; color:#1a1a2e; margin-bottom:20px;">
    Manager Dashboard
</h2>

<!-- Stat Cards -->
<div class="stat-grid">
    <div class="stat-card blue">
        <div class="label">Total Department Requests</div>
        <div class="value">${managerSummary.totalCount}</div>
    </div>
    <div class="stat-card orange">
        <div class="label">Awaiting Review</div>
        <div class="value">${managerSummary.pendingCount}</div>
    </div>
</div>

<!-- Quick Action -->
<div style="margin-bottom:24px;">
    <a href="${pageContext.request.contextPath}/departmentRequests" class="btn btn-primary">
        View All Department Requests
    </a>
</div>

<!-- Recent Department Requests -->
<div class="card">
    <div class="card-header">
        <span class="card-title">Recent Department Requests</span>
        <a href="${pageContext.request.contextPath}/departmentRequests"
           style="font-size:13px; color:#4f46e5; text-decoration:none;">View all</a>
    </div>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty managerSummary.recentRequests}">
                        <tr>
                            <td colspan="6" style="text-align:center; color:#888; padding:24px;">
                                No requests in your department yet.
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="req" items="${managerSummary.recentRequests}">
                            <tr>
                                <td>#${req.employeeId}</td>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>
                                    <c:if test="${req.status == 'PENDING'}">
                                        <a href="${pageContext.request.contextPath}/reviewRequest?id=${req.id}"
                                           class="btn btn-primary btn-sm">Review</a>
                                    </c:if>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
