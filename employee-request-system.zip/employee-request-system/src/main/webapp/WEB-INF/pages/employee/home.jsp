<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<h2 style="font-size:20px; color:#1a1a2e; margin-bottom:20px;">
    Welcome back, ${sessionScope.fullName} &#128075;
</h2>

<!-- Stat Cards -->
<div class="stat-grid">
    <div class="stat-card">
        <div class="label">Total Requests</div>
        <div class="value">${employeeSummary.total}</div>
    </div>
    <div class="stat-card orange">
        <div class="label">Pending</div>
        <div class="value">${employeeSummary.pending}</div>
    </div>
    <div class="stat-card green">
        <div class="label">Approved</div>
        <div class="value">${employeeSummary.approved}</div>
    </div>
    <div class="stat-card red">
        <div class="label">Rejected</div>
        <div class="value">${employeeSummary.rejected}</div>
    </div>
</div>

<!-- Quick Actions -->
<div style="display:flex; gap:12px; margin-bottom:24px;">
    <a href="${pageContext.request.contextPath}/newRequest" class="btn btn-primary">
        &#43; New Request
    </a>
    <a href="${pageContext.request.contextPath}/myRequests" class="btn btn-secondary">
        View All Requests
    </a>
</div>

<!-- Recent Requests -->
<div class="card">
    <div class="card-header">
        <span class="card-title">Recent Requests</span>
        <a href="${pageContext.request.contextPath}/myRequests"
           style="font-size:13px; color:#4f46e5; text-decoration:none;">View all</a>
    </div>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty employeeSummary.recentRequests}">
                        <tr>
                            <td colspan="5" style="text-align:center; color:#888; padding:24px;">
                                No requests yet.
                                <a href="${pageContext.request.contextPath}/newRequest">
                                    Submit your first request.
                                </a>
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="req" items="${employeeSummary.recentRequests}">
                            <tr>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/viewRequest?id=${req.id}"
                                       class="btn btn-secondary btn-sm">View</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
