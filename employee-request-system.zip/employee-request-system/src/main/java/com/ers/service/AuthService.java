package com.ers.service;

import com.ers.dao.UserDAO;
import com.ers.entity.User;
import com.ers.util.PasswordUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Service class handling authentication business logic.
 * Sits between LoginAction and UserDAO.
 * Responsible for: credential validation, password verification.
 */
public class AuthService {

    private static final Logger logger = LogManager.getLogger(AuthService.class);
    private final UserDAO userDAO = new UserDAO();

    /**
     * Attempts to authenticate a user with the given credentials.
     *
     * Steps:
     * 1. Look up the user by username in the database
     * 2. Check the account is active
     * 3. Verify the entered password against the stored BCrypt hash
     *
     * @param username the username entered at login
     * @param password the plain-text password entered at login
     * @return the authenticated User entity, or null if authentication fails
     */
    public User login(String username, String password) {
        if (username == null || username.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            return null;
        }

        User user = userDAO.findByUsername(username.trim());

        if (user == null) {
            logger.warn("Login failed — username not found: {}", username);
            return null;
        }

        if (!user.isActive()) {
            logger.warn("Login failed — account inactive: {}", username);
            return null;
        }

        if (!PasswordUtil.verify(password, user.getPassword())) {
            logger.warn("Login failed — wrong password for: {}", username);
            return null;
        }

        logger.info("User logged in successfully: {} ({})", username, user.getRole());
        return user;
    }
}
