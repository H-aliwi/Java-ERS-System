package com.ers.action;

import com.ers.entity.Request;
import com.ers.entity.RequestAction;
import com.ers.enums.RequestStatus;
import com.ers.enums.RequestType;
import com.ers.service.RequestService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.interceptor.SessionAware;

import java.util.List;
import java.util.Map;

public class EmpRequestAction extends ActionSupport implements SessionAware, ModelDriven<Request> {

    private static final Logger logger = LogManager.getLogger(EmpRequestAction.class);

    private final RequestService requestService = new RequestService();
    private Map<String, Object> session;

    private List<Request>       requests;
    private Request request = new Request();

    @Override
    public Request getModel() { return request; }
    private List<RequestAction> actionHistory;

    // ✅ FIX: ModelDriven يبعث ?id=6 إلى request.id مباشرة، مش إلى this.id
    private Long resolveId() {
        return (request != null) ? request.getId() : null;
    }

    // ---------------------------------------------------------------
    public String myRequests() {
        Long employeeId = (Long) session.get("userId");
        requests = requestService.getRequestsByEmployee(employeeId);
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    public String newRequest() {
        request = new Request();
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    public String submit() {
        if (!validateRequestForm()) return INPUT;

        Long employeeId = (Long) session.get("userId");
        request.setEmployeeId(employeeId);

        try {
            requestService.submitRequest(request);
            addActionMessage("Your request has been submitted successfully.");
            return SUCCESS;
        } catch (Exception e) {
            addActionError("Could not submit request. Please try again.");
            logger.error("Error submitting request", e);
            return INPUT;
        }
    }

    // ---------------------------------------------------------------
    public String view() {
        Long id = resolveId();
        if (id == null) {
            addActionError("Request not found.");
            return ERROR;
        }

        request = requestService.getRequestById(id);
        if (request == null) {
            addActionError("Request not found.");
            return ERROR;
        }

        Long userId = (Long) session.get("userId");
        String role  = (String) session.get("role");
        if (!"ADMIN".equals(role) && !request.getEmployeeId().equals(userId)) {
            return "unauthorized";
        }
        actionHistory = requestService.getRequestActions(id);
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    public String edit() {
        Long id = resolveId();
        if (id == null) {
            addActionError("Request not found.");
            return ERROR;
        }

        Request existing = requestService.getRequestById(id);
        if (existing == null) {
            addActionError("Request not found.");
            return ERROR;
        }
        // Copy properties into the model instance that is on the value stack
        this.request.setId(existing.getId());
        this.request.setEmployeeId(existing.getEmployeeId());
        this.request.setType(existing.getType());
        this.request.setStatus(existing.getStatus());
        this.request.setTitle(existing.getTitle());
        this.request.setDescription(existing.getDescription());
        this.request.setStartDate(existing.getStartDate());
        this.request.setEndDate(existing.getEndDate());
        this.request.setAmount(existing.getAmount());
        this.request.setCreatedAt(existing.getCreatedAt());
        this.request.setUpdatedAt(existing.getUpdatedAt());

        Long userId = (Long) session.get("userId");
        if (!existing.getEmployeeId().equals(userId)) {
            return "unauthorized";
        }
        if (existing.getStatus() != RequestStatus.PENDING) {
            addActionError("Only pending requests can be edited.");
            return ERROR;
        }
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    public String update() {
        if (!validateRequestForm()) return INPUT;

        try {
            requestService.updateRequest(request);
            addActionMessage("Request updated successfully.");
            return SUCCESS;
        } catch (IllegalStateException e) {
            addActionError(e.getMessage());
            return ERROR;
        } catch (Exception e) {
            addActionError("Could not update request. Please try again.");
            logger.error("Error updating request id={}", request.getId(), e);
            return INPUT;
        }
    }

    // ---------------------------------------------------------------
    public String cancel() {
        Long id = resolveId();
        if (id == null) {
            addActionError("Request not found.");
            return ERROR;
        }

        Long userId = (Long) session.get("userId");
        try {
            requestService.cancelRequest(id, userId);
            addActionMessage("Request cancelled successfully.");
            return SUCCESS;
        } catch (IllegalStateException | IllegalArgumentException e) {
            addActionError(e.getMessage());
            return ERROR;
        }
    }

    // ---------------------------------------------------------------
    private boolean validateRequestForm() {
        if (request == null) {
            addActionError("Invalid form submission");
            return false;
        }
        if (request.getType() == null) {
            addFieldError("type", "Request type is required.");
        }
        if (request.getTitle() == null || request.getTitle().trim().isEmpty()) {
            addFieldError("title", "Title is required.");
        }
        if (request.getType() == RequestType.LEAVE || request.getType() == RequestType.TRAINING) {
            if (request.getStartDate() == null) {
                addFieldError("startDate", "Start date is required.");
            }
            if (request.getEndDate() == null) {
                addFieldError("endDate", "End date is required.");
            }
            if (request.getStartDate() != null && request.getEndDate() != null
                    && request.getEndDate().isBefore(request.getStartDate())) {
                addFieldError("endDate", "End date must be after start date.");
            }
        }
        if (request.getType() == RequestType.LOAN) {
            if (request.getAmount() == null || request.getAmount().doubleValue() <= 0) {
                addFieldError("amount", "A positive loan amount is required.");
            }
        }
        return !hasFieldErrors();
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    // --- Getters for JSPs ---
    public List<Request>       getRequests()      { return requests; }
    public Request             getRequest()       { return request; }
    public List<RequestAction> getActionHistory() { return actionHistory; }
    public RequestType[]       getRequestTypes()  { return RequestType.values(); }
    public Long                getId()            { return resolveId(); }
}