package com.ers.service;

import com.ers.entity.Request;
import com.ers.entity.User;
import com.ers.util.EmailConfig;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Properties;

/**
 * Service class for sending HTML email notifications.
 *
 * All emails are sent asynchronously on a background thread.
 * This means:
 * - The user's request is never delayed by email sending
 * - If the mail server is down, the error is logged but the app continues normally
 *
 * Usage:
 *   emailService.notifyRequestSubmitted(request, employee);
 *   emailService.notifyRequestApproved(request, employee, comment);
 */
public class EmailService {

    private static final Logger logger = LogManager.getLogger(EmailService.class);

    /**
     * Sends a plain HTML email asynchronously.
     * Creates a new daemon thread for each email so it doesn't block the caller.
     * If sending fails, the exception is caught and logged — never re-thrown.
     *
     * @param to      recipient email address
     * @param subject email subject line
     * @param body    HTML email body
     */
    public void sendEmail(String to, String subject, String body) {
        // Run on a background thread — caller returns immediately
        Thread emailThread = new Thread(() -> {
            try {
                Properties props = buildMailProperties();
                Session mailSession = Session.getInstance(props, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(
                            EmailConfig.SMTP_USER,
                            EmailConfig.SMTP_PASSWORD
                        );
                    }
                });

                MimeMessage message = new MimeMessage(mailSession);
                message.setFrom(new InternetAddress(
                    EmailConfig.SMTP_USER, EmailConfig.SENDER_NAME));
                message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(to));
                message.setSubject(subject);
                // "text/html" tells the mail client to render HTML
                message.setContent(body, "text/html; charset=UTF-8");

                Transport.send(message);
                logger.info("Email sent to {} — subject: {}", to, subject);

            } catch (Exception e) {
                // Log the failure but do NOT crash the application
                logger.error("Failed to send email to {} — subject: {} — reason: {}",
                    to, subject, e.getMessage(), e);
            }
        });

        // Daemon thread: JVM can shut down even if this thread is still running
        emailThread.setDaemon(true);
        emailThread.setName("email-sender");
        emailThread.start();
    }

    /**
     * Sends a submission confirmation to the employee.
     * Called after RequestService.submitRequest() succeeds.
     *
     * @param request  the newly submitted request
     * @param employee the employee who submitted it
     */
    public void notifyRequestSubmitted(Request request, User employee) {
        String subject = "Request Submitted: " + request.getTitle();
        String body    = EmailConfig.requestSubmittedBody(employee.getFullName(), request);
        sendEmail(employee.getEmail(), subject, body);
    }

    /**
     * Sends an approval notification to the employee.
     * Called after RequestService.approveRequest() succeeds.
     *
     * @param request  the approved request
     * @param employee the employee who owns the request
     * @param comment  the manager's approval comment
     */
    public void notifyRequestApproved(Request request, User employee, String comment) {
        String subject = "Request Approved: " + request.getTitle();
        String body    = EmailConfig.requestApprovedBody(employee.getFullName(), request, comment);
        sendEmail(employee.getEmail(), subject, body);
    }

    /**
     * Sends a rejection notification to the employee.
     * Called after RequestService.rejectRequest() succeeds.
     *
     * @param request  the rejected request
     * @param employee the employee who owns the request
     * @param comment  the manager's rejection reason
     */
    public void notifyRequestRejected(Request request, User employee, String comment) {
        String subject = "Request Rejected: " + request.getTitle();
        String body    = EmailConfig.requestRejectedBody(employee.getFullName(), request, comment);
        sendEmail(employee.getEmail(), subject, body);
    }

    /**
     * Sends a cancellation confirmation to the employee.
     * Called after RequestService.cancelRequest() succeeds.
     *
     * @param request  the cancelled request
     * @param employee the employee who cancelled it
     */
    public void notifyRequestCancelled(Request request, User employee) {
        String subject = "Request Cancelled: " + request.getTitle();
        String body    = EmailConfig.requestCancelledBody(employee.getFullName(), request);
        sendEmail(employee.getEmail(), subject, body);
    }

    /**
     * Builds the JavaMail Properties object from EmailConfig settings.
     */
    private Properties buildMailProperties() {
        Properties props = new Properties();
        props.put("mail.smtp.host",            EmailConfig.SMTP_HOST);
        props.put("mail.smtp.port",            String.valueOf(EmailConfig.SMTP_PORT));
        props.put("mail.smtp.auth",            "true");
        props.put("mail.smtp.starttls.enable", String.valueOf(EmailConfig.USE_TLS));
        props.put("mail.smtp.ssl.trust",       EmailConfig.SMTP_HOST);
        return props;
    }
}
