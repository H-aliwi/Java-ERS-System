package com.ers.enums;

/**
 * The three types of requests an employee can submit.
 * Stored as STRING in the database.
 * Used in: Request entity, newRequest.jsp form, RequestService filters.
 */
public enum RequestType {
    LEAVE,
    LOAN,
    TRAINING
}
