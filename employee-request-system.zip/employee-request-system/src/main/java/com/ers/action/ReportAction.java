package com.ers.action;

import com.ers.dao.RequestDAO;
import com.ers.entity.Request;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Action class for admin reports page.
 * Aggregates request data into counts and grouped summaries for display.
 * All methods are admin-only (enforced by the admin-pkg interceptor stack).
 *
 * reports() → loads all report data in one call for the reports.jsp page
 */
public class ReportAction extends ActionSupport implements SessionAware {

    private final RequestDAO requestDAO = new RequestDAO();
    private Map<String, Object> session;

    // Data passed to reports.jsp
    private Map<String, Long> byStatus;
    private Map<String, Long> byType;
    private Map<String, Long> byMonth;
    private List<Request>     allRequests;
    private int               selectedYear;

    /**
     * Loads all report data for the reports page.
     * - Counts by status (for status distribution chart)
     * - Counts by type (for type distribution chart)
     * - Counts by month for the selected year (for monthly trend chart)
     * - Full request list for the data table
     */
    public String reports() {
        selectedYear = (selectedYear == 0) ? LocalDate.now().getYear() : selectedYear;

        byStatus    = requestDAO.countByStatus();
        byType      = requestDAO.countByType();
        allRequests = requestDAO.findAllWithFilters(null, null, null, null);
        byMonth     = buildMonthlyCount(selectedYear);

        return SUCCESS;
    }

    /**
     * Groups all requests by month for the given year.
     * Returns a map of month name → count, ordered Jan–Dec.
     * Months with zero requests are included as 0.
     *
     * @param year the year to aggregate
     * @return ordered map of month → count
     */
    private Map<String, Long> buildMonthlyCount(int year) {
        String[] months = {"Jan","Feb","Mar","Apr","May","Jun",
                           "Jul","Aug","Sep","Oct","Nov","Dec"};
        Map<String, Long> result = new LinkedHashMap<>();
        for (String m : months) result.put(m, 0L);

        allRequests.stream()
            .filter(r -> r.getCreatedAt().getYear() == year)
            .forEach(r -> {
                String month = months[r.getCreatedAt().getMonthValue() - 1];
                result.merge(month, 1L, Long::sum);
            });

        return result;
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    // --- Getters for JSPs ---
    public Map<String, Long> getByStatus()     { return byStatus; }
    public Map<String, Long> getByType()       { return byType; }
    public Map<String, Long> getByMonth()      { return byMonth; }
    public List<Request>     getAllRequests()   { return allRequests; }
    public int               getSelectedYear() { return selectedYear; }
    public int               getCurrentYear()  { return LocalDate.now().getYear(); }

    // --- Setter for year parameter from URL ---
    public void setSelectedYear(int selectedYear) { this.selectedYear = selectedYear; }
}
