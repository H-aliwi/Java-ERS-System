package com.ers.service;

import com.ers.dao.RequestActionDAO;
import com.ers.dao.RequestDAO;
import com.ers.dao.UserDAO;
import com.ers.entity.Request;
import com.ers.entity.RequestAction;
import com.ers.entity.User;
import com.ers.enums.ActionType;
import com.ers.enums.RequestStatus;
import com.ers.enums.RequestType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Service class for all request lifecycle business logic.
 * Updated in Phase 6 to trigger in-app notifications and async email
 * after every status change.
 *
 * Notification + email failures are caught internally and never
 * propagate to the caller — the core operation always completes first.
 */
public class RequestService {

    private static final Logger logger = LogManager.getLogger(RequestService.class);

    private final RequestDAO          requestDAO          = new RequestDAO();
    private final RequestActionDAO    requestActionDAO    = new RequestActionDAO();
    private final UserDAO             userDAO             = new UserDAO();
    private final NotificationService notificationService = new NotificationService();
    private final EmailService        emailService        = new EmailService();

    /**
     * Submits a new request from an employee.
     * After saving: creates a submission confirmation notification and sends email.
     *
     * @param request the Request entity populated from the form
     */
    public void submitRequest(Request request) {
        request.setStatus(RequestStatus.PENDING);
        requestDAO.save(request);
        logger.info("Request submitted: type={} by employeeId={}", request.getType(), request.getEmployeeId());

        // Notify and email — failures are caught inside each method
        User employee = userDAO.findById(request.getEmployeeId());
        if (employee != null) {
            notificationService.createNotification(
                employee.getId(),
                "Your request \"" + request.getTitle() + "\" has been submitted and is pending review."
            );
            emailService.notifyRequestSubmitted(request, employee);
        }
    }

    /**
     * Updates a PENDING request.
     * No notification sent on edit — only on status changes.
     *
     * @param request the updated Request entity
     * @throws IllegalStateException if request is not PENDING
     */
    public void updateRequest(Request request) {
        Request existing = requestDAO.findById(request.getId());
        if (existing == null) throw new IllegalArgumentException("Request not found.");
        if (existing.getStatus() != RequestStatus.PENDING)
            throw new IllegalStateException("Only pending requests can be edited.");

        request.setStatus(RequestStatus.PENDING);
        request.setEmployeeId(existing.getEmployeeId());
        requestDAO.update(request);
        logger.info("Request updated: id={}", request.getId());
    }

    /**
     * Cancels a PENDING request by the employee who owns it.
     * After cancelling: logs action, creates notification, sends email.
     *
     * @param requestId the request's primary key
     * @param userId    the ID of the employee cancelling
     * @throws IllegalStateException    if request is not PENDING
     * @throws IllegalArgumentException if the user does not own the request
     */
    public void cancelRequest(Long requestId, Long userId) {
        Request request = requestDAO.findById(requestId);
        if (request == null) throw new IllegalArgumentException("Request not found.");
        if (!request.getEmployeeId().equals(userId))
            throw new IllegalArgumentException("You can only cancel your own requests.");
        if (request.getStatus() != RequestStatus.PENDING)
            throw new IllegalStateException("Only pending requests can be cancelled.");

        request.setStatus(RequestStatus.CANCELLED);
        requestDAO.update(request);
        logAction(requestId, userId, ActionType.CANCELLED, "Cancelled by employee.");
        logger.info("Request cancelled: id={} by userId={}", requestId, userId);

        User employee = userDAO.findById(userId);
        if (employee != null) {
            notificationService.createNotification(
                userId,
                "Your request \"" + request.getTitle() + "\" has been cancelled."
            );
            emailService.notifyRequestCancelled(request, employee);
        }
    }

    /**
     * Approves a PENDING request.
     * After approving: logs action, notifies employee, sends approval email.
     *
     * @param requestId the request's primary key
     * @param managerId the ID of the approving manager
     * @param comment   optional manager comment
     * @throws IllegalStateException    if request is not PENDING
     * @throws IllegalArgumentException if manager is not in the same department
     */
    public void approveRequest(Long requestId, Long managerId, String comment) {
        Request request = getAndValidateForManager(requestId, managerId);
        request.setStatus(RequestStatus.APPROVED);
        requestDAO.update(request);
        logAction(requestId, managerId, ActionType.APPROVED, comment);
        logger.info("Request approved: id={} by managerId={}", requestId, managerId);

        User employee = userDAO.findById(request.getEmployeeId());
        if (employee != null) {
            notificationService.createNotification(
                employee.getId(),
                "Your request \"" + request.getTitle() + "\" has been approved."
            );
            emailService.notifyRequestApproved(request, employee, comment);
        }
    }

    /**
     * Rejects a PENDING request.
     * After rejecting: logs action, notifies employee, sends rejection email.
     *
     * @param requestId the request's primary key
     * @param managerId the ID of the rejecting manager
     * @param comment   rejection reason (required)
     * @throws IllegalStateException    if request is not PENDING
     * @throws IllegalArgumentException if manager is not in the same department
     */
    public void rejectRequest(Long requestId, Long managerId, String comment) {
        Request request = getAndValidateForManager(requestId, managerId);
        request.setStatus(RequestStatus.REJECTED);
        requestDAO.update(request);
        logAction(requestId, managerId, ActionType.REJECTED, comment);
        logger.info("Request rejected: id={} by managerId={}", requestId, managerId);

        User employee = userDAO.findById(request.getEmployeeId());
        if (employee != null) {
            notificationService.createNotification(
                employee.getId(),
                "Your request \"" + request.getTitle() + "\" has been rejected."
                + (comment != null && !comment.isEmpty() ? " Reason: " + comment : "")
            );
            emailService.notifyRequestRejected(request, employee, comment);
        }
    }

    /**
     * Shared validation for approve and reject:
     * 1. Request must exist and be PENDING
     * 2. Manager must be in the same department as the employee
     */
    private Request getAndValidateForManager(Long requestId, Long managerId) {
        Request request = requestDAO.findById(requestId);
        if (request == null) throw new IllegalArgumentException("Request not found.");
        if (request.getStatus() != RequestStatus.PENDING)
            throw new IllegalStateException("Only pending requests can be reviewed.");

        User manager  = userDAO.findById(managerId);
        User employee = userDAO.findById(request.getEmployeeId());
        if (manager == null || employee == null)
            throw new IllegalArgumentException("User not found.");
        if (!manager.getDepartmentId().equals(employee.getDepartmentId()))
            throw new IllegalArgumentException("You can only review requests from your department.");

        return request;
    }

    /** Inserts a row into request_actions for the audit trail. */
    private void logAction(Long requestId, Long actionBy, ActionType action, String comment) {
        requestActionDAO.save(new RequestAction(requestId, actionBy, action, comment));
    }

    // --- Simple read methods ---

    public Request getRequestById(Long id) {
        return requestDAO.findById(id);
    }

    public List<Request> getRequestsByEmployee(Long employeeId) {
        return requestDAO.findByEmployee(employeeId);
    }

    public List<Request> getDepartmentRequests(Long departmentId) {
        return requestDAO.findByDepartment(departmentId);
    }

    public List<Request> getAllRequests(RequestType type, RequestStatus status,
                                        LocalDate dateFrom, LocalDate dateTo) {
        return requestDAO.findAllWithFilters(type, status, dateFrom, dateTo);
    }

    public List<RequestAction> getRequestActions(Long requestId) {
        return requestActionDAO.findByRequest(requestId);
    }

    public Map<String, Long> getStatusCountsForEmployee(Long employeeId) {
        return requestDAO.countByStatusForEmployee(employeeId);
    }
}
