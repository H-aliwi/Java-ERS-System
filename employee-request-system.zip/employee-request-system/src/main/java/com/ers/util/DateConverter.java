package com.ers.util;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.util.StrutsTypeConverter;

public class DateConverter extends StrutsTypeConverter {  // ✅ extends وليس implements

    private static final Logger logger = LogManager.getLogger(DateConverter.class);

    private static final DateTimeFormatter HTML5_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final DateTimeFormatter USER_FORMATTER =
            new DateTimeFormatterBuilder()
                .appendOptional(DateTimeFormatter.ofPattern("dd-MMM-yyyy"))
                .appendOptional(DateTimeFormatter.ofPattern("d-MMM-yyyy"))
                .toFormatter(Locale.ENGLISH);

    // ✅ String[] → LocalDate
    @Override
    public Object convertFromString(Map context, String[] values, Class toClass) {

        if (values == null || values.length == 0) return null;

        String dateStr = values[0].trim();
        if (dateStr.isEmpty()) return null;

        // 1) HTML5 date input → yyyy-MM-dd
        try {
            return LocalDate.parse(dateStr, HTML5_FORMATTER);
        } catch (DateTimeParseException ignored) {}

        // 2) User-friendly → dd-MMM-yyyy or d-MMM-yyyy
        try {
            return LocalDate.parse(dateStr, USER_FORMATTER);
        } catch (DateTimeParseException ignored) {}

        logger.warn("Failed to parse date: {}", dateStr);
        return null;  // يُطلق field-error تلقائياً
    }

    // ✅ LocalDate → String
    @Override
    public String convertToString(Map context, Object value) {

        if (value instanceof LocalDate) {
            return ((LocalDate) value).format(HTML5_FORMATTER);
        }

        // دعم java.util.Date للتوافق
        if (value instanceof java.util.Date) {
            return ((java.util.Date) value).toInstant()
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate()
                    .format(HTML5_FORMATTER);
        }

        return "";
    }
}