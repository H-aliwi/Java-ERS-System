package com.ers.dao;

import com.ers.entity.Department;
import com.ers.util.DatabaseConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DAO for the departments table.
 */
public class DepartmentDAO {

    private static final Logger logger = LogManager.getLogger(DepartmentDAO.class);

    private Connection getConnection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    // ================= SAVE =================
    public void save(Department d) {
        String sql = "INSERT INTO departments (name, description, manager_id) VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, d.getName());
            stmt.setString(2, d.getDescription());
            stmt.setObject(3, d.getManagerId());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        d.setId(rs.getLong(1));
                    }
                }
            }

            logger.debug("Department saved: {}", d.getName());
        } catch (Exception e) {
            logger.error("Error saving department {}: {}", d.getName(), e.getMessage(), e);
            throw new RuntimeException("Could not save department", e);
        }
    }

    // ================= UPDATE =================
    public void update(Department d) {
        String sql = "UPDATE departments SET name=?, description=?, manager_id=? WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, d.getName());
            stmt.setString(2, d.getDescription());
            stmt.setObject(3, d.getManagerId());
            stmt.setLong(4, d.getId());

            int affected = stmt.executeUpdate();
            logger.debug("Department updated: {} (rows: {})", d.getName(), affected);

        } catch (Exception e) {
            logger.error("Error updating department {}: {}", d.getName(), e.getMessage(), e);
            throw new RuntimeException("Could not update department", e);
        }
    }

    // ================= DELETE =================
    public void delete(Long id) {
        String sql = "DELETE FROM departments WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            int affected = stmt.executeUpdate();
            logger.debug("Department deleted: id={} (rows: {})", id, affected);

        } catch (Exception e) {
            logger.error("Error deleting department id={}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Could not delete department", e);
        }
    }

    // ================= FIND BY ID =================
    public Department findById(Long id) {
        String sql = "SELECT * FROM departments WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapDepartment(rs);
                }
            }

        } catch (Exception e) {
            logger.error("Error finding department by id={}: {}", id, e.getMessage(), e);
        }

        return null;
    }

    // ================= FIND ALL =================
    public List<Department> findAll() {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT * FROM departments";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapDepartment(rs));
            }

        } catch (Exception e) {
            logger.error("Error fetching all departments: {}", e.getMessage(), e);
        }

        return list;
    }

    public List<Department> findAllOrdered() {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT * FROM departments ORDER BY name";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapDepartment(rs));
            }

        } catch (Exception e) {
            logger.error("Error fetching all departments ordered: {}", e.getMessage(), e);
            return Collections.emptyList();
        }

        return list;
    }

    public Map<Long, Long> findEmployeeCountPerDepartment() {
        Map<Long, Long> counts = new HashMap<>();
        String sql = "SELECT department_id, COUNT(*) FROM users WHERE active=true AND department_id IS NOT NULL GROUP BY department_id";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                counts.put(rs.getLong(1), rs.getLong(2));
            }

        } catch (Exception e) {
            logger.error("Error fetching employee counts per department: {}", e.getMessage(), e);
        }

        return counts;
    }

    // ================= HELPER =================
    private Department mapDepartment(ResultSet rs) throws SQLException {
        Department d = new Department();
        d.setId(rs.getLong("id"));
        d.setName(rs.getString("name"));
        d.setDescription(rs.getString("description"));
        d.setManagerId(rs.getObject("manager_id", Long.class));
        return d;
    }
}
