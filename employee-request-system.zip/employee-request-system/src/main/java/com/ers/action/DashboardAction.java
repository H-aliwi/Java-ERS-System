package com.ers.action;

import com.ers.service.DashboardService;
import com.ers.service.DashboardService.AdminSummary;
import com.ers.service.DashboardService.EmployeeSummary;
import com.ers.service.DashboardService.ManagerSummary;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;

import java.util.Map;

/**
 * Action class for all three dashboard pages.
 *
 * employeeDashboard() → /home.action         → home.jsp
 * managerDashboard()  → /managerDashboard    → managerDashboard.jsp
 * adminDashboard()    → /adminDashboard      → adminDashboard.jsp
 *
 * Each method loads only the data relevant to the calling user's role.
 */
public class DashboardAction extends ActionSupport implements SessionAware {

    private final DashboardService dashboardService = new DashboardService();
    private Map<String, Object> session;

    // Data holders passed to JSPs via getters
    private EmployeeSummary employeeSummary;
    private ManagerSummary  managerSummary;
    private AdminSummary    adminSummary;

    /**
     * Loads the employee dashboard summary.
     * Reads the logged-in user's ID from the session.
     */
    public String employeeDashboard() {
        Long userId = (Long) session.get("userId");
        employeeSummary = dashboardService.getEmployeeSummary(userId);
        return SUCCESS;
    }

    /**
     * Loads the manager dashboard summary.
     * Reads the manager's department ID from the session.
     */
    public String managerDashboard() {
        Long departmentId = (Long) session.get("departmentId");
        if (departmentId == null) {
            addActionError("You are not assigned to a department.");
            return ERROR;
        }
        managerSummary = dashboardService.getManagerSummary(departmentId);
        return SUCCESS;
    }

    /**
     * Loads the admin dashboard summary.
     * No session data needed — loads system-wide statistics.
     */
    public String adminDashboard() {
        adminSummary = dashboardService.getAdminSummary();
        return SUCCESS;
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    // --- Getters for JSPs ---
    public EmployeeSummary getEmployeeSummary() { return employeeSummary; }
    public ManagerSummary  getManagerSummary()  { return managerSummary; }
    public AdminSummary    getAdminSummary()    { return adminSummary; }
}
