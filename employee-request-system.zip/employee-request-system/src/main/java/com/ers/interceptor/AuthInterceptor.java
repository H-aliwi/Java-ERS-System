package com.ers.interceptor;

import com.ers.action.LoginAction;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;

/**
 * Security interceptor that runs before every Action in the secured packages.
 *
 * Responsibilities:
 * 1. Check if a user session exists — redirect to login if not
 * 2. If allowedRoles is set, check the user's role is permitted
 *
 * allowedRoles is injected by Struts from the <param name="allowedRoles"> on
 * the interceptor-ref in struts.xml. Each interceptor-stack can define its own
 * value (e.g. "ADMIN" for adminStack, "MANAGER,ADMIN" for managerStack).
 */
public class AuthInterceptor extends AbstractInterceptor {

    private static final Logger logger = LogManager.getLogger(AuthInterceptor.class);

    /**
     * Comma-separated roles allowed for this interceptor instance.
     * Set via <param name="allowedRoles"> in struts.xml.
     * Null or empty means any authenticated role is allowed.
     */
    private String allowedRoles;

    @Override
    public String intercept(ActionInvocation invocation) throws Exception {
        Map<String, Object> session = invocation.getInvocationContext().getSession();

        // Step 1: Check if user is logged in
        String role = (String) session.get(LoginAction.SESSION_ROLE);
        if (role == null) {
            logger.warn("Unauthenticated access attempt — redirecting to login.");
            return "login";
        }

        // Step 2: Check role permission if allowedRoles is configured
        if (allowedRoles != null && !allowedRoles.trim().isEmpty()) {
            boolean permitted = false;
            for (String allowed : allowedRoles.split(",")) {
                if (allowed.trim().equalsIgnoreCase(role)) {
                    permitted = true;
                    break;
                }
            }
            if (!permitted) {
                logger.warn("Unauthorized access — role {} not in [{}]", role, allowedRoles);
                return "unauthorized";
            }
        }

        return invocation.invoke();
    }

    /** Struts injects this from <param name="allowedRoles"> in struts.xml */
    public void setAllowedRoles(String allowedRoles) {
        this.allowedRoles = allowedRoles;
    }
}
