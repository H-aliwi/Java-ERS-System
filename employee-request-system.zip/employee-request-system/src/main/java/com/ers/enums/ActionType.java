package com.ers.enums;

/**
 * Type of action taken on a request (audit trail).
 * Stored as STRING in the database.
 * Used in: RequestAction entity, RequestService when logging actions.
 */
public enum ActionType {
    APPROVED,
    REJECTED,
    CANCELLED
}
