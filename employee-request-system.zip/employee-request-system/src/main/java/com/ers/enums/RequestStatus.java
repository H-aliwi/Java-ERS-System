package com.ers.enums;

/**
 * Lifecycle status of a request.
 * - PENDING: just submitted, awaiting manager review
 * - APPROVED: manager approved
 * - REJECTED: manager rejected
 * - CANCELLED: employee cancelled before approval
 * 
 * Stored as STRING in the database.
 * Used in: Request entity, RequestService business logic, JSP status badges.
 */
public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
