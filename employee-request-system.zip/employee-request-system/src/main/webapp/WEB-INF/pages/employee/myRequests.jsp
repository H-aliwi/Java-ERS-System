<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s"   uri="/struts-tags" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
    <h2 style="font-size:20px; color:#1a1a2e;">My Requests</h2>
    <a href="${pageContext.request.contextPath}/newRequest" class="btn btn-primary">
        &#43; New Request
    </a>
</div>

<s:if test="hasActionMessages()">
    <div class="alert alert-success"><s:actionmessage/></div>
</s:if>
<s:if test="hasActionErrors()">
    <div class="alert alert-error"><s:actionerror/></div>
</s:if>

<div class="card">
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty requests}">
                        <tr>
                            <td colspan="8" style="text-align:center; color:#888; padding:30px;">
                                You have not submitted any requests yet.
                                <a href="${pageContext.request.contextPath}/newRequest">Submit one now.</a>
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="req" items="${requests}" varStatus="st">
                            <tr>
                                <td style="color:#888;">${st.index + 1}</td>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>${empty req.startDate ? '—' : req.startDate}</td>
                                <td>${empty req.endDate   ? '—' : req.endDate}</td>
                                <td>
                                    ID: ${req.id} <br/>
                                
                                    <a href="${pageContext.request.contextPath}/viewRequest?id=${req.id}"
                                       class="btn btn-secondary btn-sm">View</a>
                                    <c:if test="${req.status == 'PENDING'}">
                                        <a href="${pageContext.request.contextPath}/editRequest?id=${req.id}"
                                           class="btn btn-warning btn-sm">Edit</a>
                                        <a href="${pageContext.request.contextPath}/cancelRequest?id=${req.id}"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Cancel this request?')">Cancel</a>
                                    </c:if>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
