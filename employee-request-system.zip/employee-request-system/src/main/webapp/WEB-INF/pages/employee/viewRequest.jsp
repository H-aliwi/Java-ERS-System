<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s"   uri="/struts-tags" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<div style="max-width:760px;">

    <div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
        <a href="javascript:history.back()" class="btn btn-secondary btn-sm">&#8592; Back</a>
        <h2 style="font-size:20px; color:#1a1a2e;">Request Details</h2>
    </div>

    <s:if test="hasActionErrors()">
        <div class="alert alert-error"><s:actionerror/></div>
    </s:if>

    <!-- Request Details Card -->
    <div class="card" style="margin-bottom:20px;">
        <div class="card-header">
            <span class="card-title">${request.title}</span>
            <c:choose>
                <c:when test="${request.status == 'PENDING'}">
                    <span class="badge badge-pending">Pending</span>
                </c:when>
                <c:when test="${request.status == 'APPROVED'}">
                    <span class="badge badge-approved">Approved</span>
                </c:when>
                <c:when test="${request.status == 'REJECTED'}">
                    <span class="badge badge-rejected">Rejected</span>
                </c:when>
                <c:otherwise>
                    <span class="badge badge-cancelled">Cancelled</span>
                </c:otherwise>
            </c:choose>
        </div>

        <table style="width:100%; border-collapse:collapse;">
            <tr>
                <td style="padding:8px 0; color:#888; width:160px;">Type</td>
                <td><strong>${request.type}</strong></td>
            </tr>
            <tr>
                <td style="padding:8px 0; color:#888;">Submitted</td>
                <td>${request.createdAt}</td>
            </tr>
            <c:if test="${not empty request.startDate}">
                <tr>
                    <td style="padding:8px 0; color:#888;">Start Date</td>
                    <td>${request.startDate}</td>
                </tr>
            </c:if>
            <c:if test="${not empty request.endDate}">
                <tr>
                    <td style="padding:8px 0; color:#888;">End Date</td>
                    <td>${request.endDate}</td>
                </tr>
            </c:if>
            <c:if test="${not empty request.amount}">
                <tr>
                    <td style="padding:8px 0; color:#888;">Loan Amount</td>
                    <td><strong>BHD ${request.amount}</strong></td>
                </tr>
            </c:if>
            <c:if test="${not empty request.description}">
                <tr>
                    <td style="padding:8px 0; color:#888; vertical-align:top;">Description</td>
                    <td style="padding:8px 0;">${request.description}</td>
                </tr>
            </c:if>
        </table>

        <!-- Action buttons for PENDING requests owned by the logged-in employee -->
        <c:if test="${request.status == 'PENDING' && sessionScope.role == 'EMPLOYEE'}">
            <div style="margin-top:16px; display:flex; gap:10px;">
                <a href="${pageContext.request.contextPath}/editRequest?id=${request.id}"
                   class="btn btn-warning btn-sm">Edit Request</a>
                <a href="${pageContext.request.contextPath}/cancelRequest?id=${request.id}"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Are you sure you want to cancel this request?')">
                    Cancel Request
                </a>
            </div>
        </c:if>
    </div>

    <!-- Action History Timeline -->
    <div class="card">
        <div class="card-title" style="margin-bottom:16px;">Action History</div>
        <c:choose>
            <c:when test="${empty actionHistory}">
                <p style="color:#888; font-size:13px;">No actions taken yet.</p>
            </c:when>
            <c:otherwise>
                <div style="border-left:3px solid #e0e0e0; padding-left:20px;">
                    <c:forEach var="act" items="${actionHistory}">
                        <div style="margin-bottom:18px; position:relative;">
                            <div style="width:12px; height:12px; border-radius:50%; position:absolute;
                                        left:-27px; top:3px;
                                        background:${act.action == 'APPROVED' ? '#16a34a' :
                                                     act.action == 'REJECTED' ? '#dc2626' : '#6b7280'};"></div>
                            <div style="font-size:13px; font-weight:600; color:#1a1a2e;">
                                ${act.action}
                                <span style="font-weight:400; color:#888; margin-left:8px;">
                                    by User #${act.actionBy}
                                </span>
                            </div>
                            <div style="font-size:12px; color:#888; margin-top:2px;">
                                ${act.actionDate}
                            </div>
                            <c:if test="${not empty act.comment}">
                                <div style="margin-top:6px; font-size:13px; color:#555;
                                            background:#f8f9fa; padding:8px 12px; border-radius:6px;">
                                    "${act.comment}"
                                </div>
                            </c:if>
                        </div>
                    </c:forEach>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

</div>
