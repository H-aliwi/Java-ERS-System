<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<h2 style="font-size:20px; color:#1a1a2e; margin-bottom:20px;">Admin Dashboard</h2>

<!-- System Stat Cards -->
<div class="stat-grid">
    <div class="stat-card blue">
        <div class="label">Total Users</div>
        <div class="value">${adminSummary.totalUsers}</div>
    </div>
    <div class="stat-card">
        <div class="label">Total Requests</div>
        <div class="value">${adminSummary.totalRequests}</div>
    </div>
    <div class="stat-card orange">
        <div class="label">Pending</div>
        <div class="value">${adminSummary.pending}</div>
    </div>
    <div class="stat-card green">
        <div class="label">Approved</div>
        <div class="value">${adminSummary.approved}</div>
    </div>
    <div class="stat-card red">
        <div class="label">Rejected</div>
        <div class="value">${adminSummary.rejected}</div>
    </div>
</div>

<!-- Request Type Breakdown -->
<div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:24px;">
    <div class="card" style="text-align:center; padding:20px;">
        <div style="font-size:28px; font-weight:700; color:#4f46e5;">${adminSummary.leaveCount}</div>
        <div style="color:#888; font-size:12px; text-transform:uppercase; margin-top:4px;">Leave Requests</div>
    </div>
    <div class="card" style="text-align:center; padding:20px;">
        <div style="font-size:28px; font-weight:700; color:#d97706;">${adminSummary.loanCount}</div>
        <div style="color:#888; font-size:12px; text-transform:uppercase; margin-top:4px;">Loan Requests</div>
    </div>
    <div class="card" style="text-align:center; padding:20px;">
        <div style="font-size:28px; font-weight:700; color:#16a34a;">${adminSummary.trainingCount}</div>
        <div style="color:#888; font-size:12px; text-transform:uppercase; margin-top:4px;">Training Requests</div>
    </div>
</div>

<!-- Quick Links -->
<div style="display:flex; gap:12px; margin-bottom:24px;">
    <a href="${pageContext.request.contextPath}/employees"  class="btn btn-primary">Manage Employees</a>
    <a href="${pageContext.request.contextPath}/allRequests" class="btn btn-secondary">All Requests</a>
    <a href="${pageContext.request.contextPath}/reports"     class="btn btn-secondary">Reports</a>
</div>

<!-- Recent Requests -->
<div class="card">
    <div class="card-header">
        <span class="card-title">Recent Requests (System-wide)</span>
        <a href="${pageContext.request.contextPath}/allRequests"
           style="font-size:13px; color:#4f46e5; text-decoration:none;">View all</a>
    </div>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty adminSummary.recentRequests}">
                        <tr>
                            <td colspan="6" style="text-align:center; color:#888; padding:24px;">
                                No requests in the system yet.
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="req" items="${adminSummary.recentRequests}">
                            <tr>
                                <td>#${req.employeeId}</td>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/viewRequest?id=${req.id}"
                                       class="btn btn-secondary btn-sm">View</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
