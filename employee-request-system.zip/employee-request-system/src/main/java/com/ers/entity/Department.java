package com.ers.entity;

/**
 * Plain POJO representing a row in the "departments" table.
 * No JPA/Hibernate annotations — mapped manually in DepartmentDAO.
 */
public class Department {

    private Long id;
    private String name;
    private String description;
    private Long managerId;

    // --- Constructors ---

    public Department() {}

    public Department(String name, String description, Long managerId) {
        this.name = name;
        this.description = description;
        this.managerId = managerId;
    }

    // --- Getters and Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Long getManagerId() { return managerId; }
    public void setManagerId(Long managerId) { this.managerId = managerId; }
}
