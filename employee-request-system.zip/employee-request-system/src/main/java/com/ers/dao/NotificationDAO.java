package com.ers.dao;

import com.ers.entity.Notification;
import com.ers.util.DatabaseConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DAO for the notifications table.
 */
public class NotificationDAO {

    private static final Logger logger = LogManager.getLogger(NotificationDAO.class);

    private Connection getConnection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    // ================= SAVE =================
    public void save(Notification n) {
        String sql = "INSERT INTO notifications (user_id, message, is_read, created_at) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setLong(1, n.getUserId());
            stmt.setString(2, n.getMessage());
            stmt.setBoolean(3, n.isRead());
            stmt.setTimestamp(4, Timestamp.valueOf(n.getCreatedAt() != null ? n.getCreatedAt() : LocalDateTime.now()));

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        n.setId(rs.getLong(1));
                    }
                }
            }

            logger.debug("Notification saved for user {}: {}", n.getUserId(), n.getMessage());
        } catch (Exception e) {
            logger.error("Error saving notification for user {}: {}", n.getUserId(), e.getMessage(), e);
            throw new RuntimeException("Could not save notification", e);
        }
    }

    // ================= UPDATE =================
    public void update(Notification n) {
        String sql = "UPDATE notifications SET user_id=?, message=?, is_read=?, created_at=? WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, n.getUserId());
            stmt.setString(2, n.getMessage());
            stmt.setBoolean(3, n.isRead());
            stmt.setTimestamp(4, Timestamp.valueOf(n.getCreatedAt()));
            stmt.setLong(5, n.getId());

            int affected = stmt.executeUpdate();
            logger.debug("Notification updated: id={} (rows: {})", n.getId(), affected);

        } catch (Exception e) {
            logger.error("Error updating notification id={}: {}", n.getId(), e.getMessage(), e);
            throw new RuntimeException("Could not update notification", e);
        }
    }

    // ================= DELETE =================
    public void delete(Long id) {
        String sql = "DELETE FROM notifications WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            int affected = stmt.executeUpdate();
            logger.debug("Notification deleted: id={} (rows: {})", id, affected);

        } catch (Exception e) {
            logger.error("Error deleting notification id={}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Could not delete notification", e);
        }
    }

    // ================= FIND BY ID =================
    public Notification findById(Long id) {
        String sql = "SELECT * FROM notifications WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapNotification(rs);
                }
            }

        } catch (Exception e) {
            logger.error("Error finding notification by id={}: {}", id, e.getMessage(), e);
        }

        return null;
    }

    // ================= FIND ALL =================
    public List<Notification> findAll() {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications ORDER BY created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapNotification(rs));
            }

        } catch (Exception e) {
            logger.error("Error fetching all notifications: {}", e.getMessage(), e);
        }

        return list;
    }

    public List<Notification> findByUser(Long userId) {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapNotification(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding notifications for user {}: {}", userId, e.getMessage(), e);
        }

        return list;
    }

    public List<Notification> findUnread(Long userId) {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications WHERE user_id=? AND is_read=false ORDER BY created_at DESC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapNotification(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding unread notifications for user {}: {}", userId, e.getMessage(), e);
        }

        return list;
    }

    public void markAsRead(Long id) {
        String sql = "UPDATE notifications SET is_read=true WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            int affected = stmt.executeUpdate();
            logger.debug("Notification marked as read: id={} (rows: {})", id, affected);

        } catch (Exception e) {
            logger.error("Error marking notification {} as read: {}", id, e.getMessage(), e);
            throw new RuntimeException("Could not mark notification as read", e);
        }
    }

    public void markAllAsRead(Long userId) {
        String sql = "UPDATE notifications SET is_read=true WHERE user_id=? AND is_read=false";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, userId);
            int affected = stmt.executeUpdate();
            logger.debug("All notifications marked as read for user {} (rows: {})", userId, affected);

        } catch (Exception e) {
            logger.error("Error marking all notifications as read for user {}: {}", userId, e.getMessage(), e);
            throw new RuntimeException("Could not mark all notifications as read", e);
        }
    }

    // ================= HELPER =================
    private Notification mapNotification(ResultSet rs) throws SQLException {
        Notification n = new Notification();
        n.setId(rs.getLong("id"));
        n.setUserId(rs.getLong("user_id"));
        n.setMessage(rs.getString("message"));
        n.setRead(rs.getBoolean("is_read"));
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            n.setCreatedAt(createdAt.toLocalDateTime());
        }
        return n;
    }
}
