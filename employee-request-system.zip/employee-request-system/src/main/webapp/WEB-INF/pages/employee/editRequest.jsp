<%@ page contentType="text/html;charset=UTF-8" %> <%@ taglib prefix="s"
uri="/struts-tags" %> <%@ taglib prefix="c"
uri="http://java.sun.com/jsp/jstl/core" %>

<div style="max-width: 680px">
  <div
    style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px"
  >
    <a
      href="${pageContext.request.contextPath}/myRequests"
      class="btn btn-secondary btn-sm"
      >&#8592; Back</a
    >
    <h2 style="font-size: 20px; color: #1a1a2e">Edit Request</h2>
  </div>

  <div class="alert alert-info">
    Only the title, description, dates, and amount can be changed. Type cannot
    be changed.
  </div>

  <s:if test="hasActionErrors()">
    <div class="alert alert-error"><s:actionerror /></div>
  </s:if>

  <div class="card">
    <s:form action="updateRequest" method="post" theme="simple" id="editForm">
      <s:hidden name="id" value="%{request.id}" />
      <s:hidden name="employeeId" value="%{request.employeeId}" />
      <s:hidden name="status" value="%{request.status.name()}" />
      <s:hidden name="type" value="%{request.type.name()}" />
      <s:hidden name="createdAt" value="%{request.createdAt}" />
      <s:hidden name="updatedAt" value="%{request.updatedAt}" />

      <!-- Type display (read-only) -->
      <div class="form-group">
        <label>Request Type</label>
        <input
          type="text"
          value="<s:property value='request.type.name()' />"
          disabled
          style="background: #f5f5f5; color: #888"
        />
      </div>

      <!-- Title -->
      <div class="form-group">
        <label>Title <span class="required">*</span></label>
        <s:textfield name="title" id="title" maxlength="150" value="%{request.title}" />
        <s:fielderror fieldName="title" cssClass="field-error-msg" />
      </div>

      <!-- Description -->
      <div class="form-group">
        <label>Description</label>
        <s:textarea name="description" rows="3" value="%{request.description}" />
      </div>

      <!-- Date fields for LEAVE and TRAINING -->
      <c:if test="${request.type == 'LEAVE' || request.type == 'TRAINING'}">
        <div class="form-grid">
          <div class="form-group">
            <label>Start Date <span class="required">*</span></label>
            <s:textfield name="startDate" id="startDate" type="date" value="%{request.startDate}" />
            <s:fielderror fieldName="startDate" cssClass="field-error-msg" />
          </div>
          <div class="form-group">
            <label>End Date <span class="required">*</span></label>
            <s:textfield name="endDate" id="endDate" type="date" value="%{request.endDate}" />
            <s:fielderror fieldName="endDate" cssClass="field-error-msg" />
          </div>
        </div>
      </c:if>

      <!-- Amount for LOAN -->
      <c:if test="${request.type == 'LOAN'}">
        <div class="form-group">
          <label>Loan Amount <span class="required">*</span></label>
          <s:textfield name="amount" id="amount" type="number" value="%{request.amount}" />
          <s:fielderror fieldName="amount" cssClass="field-error-msg" />
        </div>
      </c:if>

      <div style="display: flex; gap: 10px; margin-top: 8px">
        <button type="submit" class="btn btn-primary">Save Changes</button>
        <a
          href="${pageContext.request.contextPath}/myRequests"
          class="btn btn-secondary"
        >
          Cancel
        </a>
      </div>
    </s:form>
  </div>
</div>
