package com.ers.action;

import com.ers.dao.RequestDAO;
import com.ers.entity.Request;
import com.ers.enums.RequestStatus;
import com.ers.enums.RequestType;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Action class for the admin "All Requests" page.
 * Supports filtering by type, status, and date range.
 */
public class AdminRequestAction extends ActionSupport implements SessionAware {

    private final RequestDAO requestDAO = new RequestDAO();
    private Map<String, Object> session;

    // Filter parameters bound from URL query string
    private String filterType;
    private String filterStatus;
    private String dateFrom;
    private String dateTo;

    // Data passed to JSP
    private List<Request> allRequests;

    /**
     * Loads all requests with optional filters applied.
     * Any filter left blank is ignored (returns all).
     */
    public String allRequests() {
        RequestType   type   = parseEnum(RequestType.class,   filterType);
        RequestStatus status = parseEnum(RequestStatus.class, filterStatus);
        LocalDate     from   = parseDate(dateFrom);
        LocalDate     to     = parseDate(dateTo);

        allRequests = requestDAO.findAllWithFilters(type, status, from, to);
        return SUCCESS;
    }

    private <E extends Enum<E>> E parseEnum(Class<E> clazz, String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return Enum.valueOf(clazz, value.trim()); }
        catch (IllegalArgumentException e) { return null; }
    }

    private LocalDate parseDate(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try { return LocalDate.parse(value.trim()); }
        catch (Exception e) { return null; }
    }

    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    public List<Request>    getAllRequests()    { return allRequests; }
    public RequestType[]    getRequestTypes()  { return RequestType.values(); }
    public RequestStatus[]  getRequestStatuses(){ return RequestStatus.values(); }
    public String           getFilterType()    { return filterType; }
    public String           getFilterStatus()  { return filterStatus; }
    public String           getDateFrom()      { return dateFrom; }
    public String           getDateTo()        { return dateTo; }

    public void setFilterType(String filterType)     { this.filterType = filterType; }
    public void setFilterStatus(String filterStatus) { this.filterStatus = filterStatus; }
    public void setDateFrom(String dateFrom)         { this.dateFrom = dateFrom; }
    public void setDateTo(String dateTo)             { this.dateTo = dateTo; }
}
