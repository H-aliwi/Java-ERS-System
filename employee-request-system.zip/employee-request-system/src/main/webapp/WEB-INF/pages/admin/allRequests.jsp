<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s"   uri="/struts-tags" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
    <h2 style="font-size:20px; color:#1a1a2e;">All Requests</h2>
</div>

<s:if test="hasActionMessages()">
    <div class="alert alert-success"><s:actionmessage/></div>
</s:if>

<!-- Filters -->
<div class="card" style="padding:16px 20px; margin-bottom:16px;">
    <s:form action="allRequests" method="get" theme="simple"
            style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end;">
        <div>
            <label style="display:block; margin-bottom:4px;">Type</label>
            <s:select name="filterType" list="requestTypes"
                      listKey="name()" listValue="name()"
                      headerKey="" headerValue="All Types"
                      cssStyle="width:140px;"/>
        </div>
        <div>
            <label style="display:block; margin-bottom:4px;">Status</label>
            <s:select name="filterStatus" list="requestStatuses"
                      listKey="name()" listValue="name()"
                      headerKey="" headerValue="All Statuses"
                      cssStyle="width:140px;"/>
        </div>
        <div>
            <label style="display:block; margin-bottom:4px;">From</label>
            <s:textfield name="dateFrom" type="date" cssStyle="width:150px;"/>
        </div>
        <div>
            <label style="display:block; margin-bottom:4px;">To</label>
            <s:textfield name="dateTo" type="date" cssStyle="width:150px;"/>
        </div>
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <a href="${pageContext.request.contextPath}/allRequests"
           class="btn btn-secondary btn-sm">Clear</a>
    </s:form>
</div>

<!-- Requests Table -->
<div class="card">
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Employee ID</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty allRequests}">
                        <tr>
                            <td colspan="7" style="text-align:center; color:#888; padding:30px;">
                                No requests found.
                            </td>
                        </tr>
                    </c:when>
                    
                    <c:otherwise>
                        <c:forEach var="req" items="${allRequests}" varStatus="st">
                            <tr>
                                <td style="color:#888;">${st.index + 1}</td>
                                <td>#${req.employeeId}</td>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/viewRequest?id=${req.id}"
                                       class="btn btn-secondary btn-sm">View</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
