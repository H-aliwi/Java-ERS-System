package com.ers.service;

import com.ers.dao.RequestDAO;
import com.ers.dao.UserDAO;
import com.ers.entity.Request;
import com.ers.enums.RequestStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Map;

/**
 * Service class that assembles dashboard summary data for each role.
 * Each method returns only the data relevant to the calling user's role.
 * No business logic — only aggregation of DAO results.
 */
public class DashboardService {

    private static final Logger logger = LogManager.getLogger(DashboardService.class);

    private final RequestDAO requestDAO = new RequestDAO();
    private final UserDAO    userDAO    = new UserDAO();

    /**
     * Builds the employee dashboard summary.
     * Returns request counts grouped by status and the 5 most recent requests.
     *
     * @param employeeId the logged-in employee's user ID
     * @return EmployeeSummary containing counts and recent requests
     */
    public EmployeeSummary getEmployeeSummary(Long employeeId) {
        Map<String, Long> counts  = requestDAO.countByStatusForEmployee(employeeId);
        List<Request>     recent  = requestDAO.findRecentByEmployee(employeeId);
        return new EmployeeSummary(
            counts.getOrDefault("PENDING",   0L),
            counts.getOrDefault("APPROVED",  0L),
            counts.getOrDefault("REJECTED",  0L),
            counts.getOrDefault("CANCELLED", 0L),
            recent
        );
    }

    /**
     * Builds the manager dashboard summary.
     * Returns pending count, total count, and 5 most recent requests in the department.
     *
     * @param departmentId the manager's department ID
     * @return ManagerSummary containing counts and recent requests
     */
    public ManagerSummary getManagerSummary(Long departmentId) {
        List<Request> allRequests = requestDAO.findByDepartment(departmentId);
        List<Request> recent      = requestDAO.findRecentByDepartment(departmentId);

        long pendingCount = allRequests.stream()
                .filter(r -> r.getStatus() == RequestStatus.PENDING)
                .count();

        return new ManagerSummary(pendingCount, allRequests.size(), recent);
    }

    /**
     * Builds the admin dashboard summary.
     * Returns total user count, total request count, counts by status and type.
     *
     * @return AdminSummary with system-wide statistics
     */
    public AdminSummary getAdminSummary() {
        long              totalUsers    = userDAO.findAllActive().size();
        Map<String, Long> byStatus      = requestDAO.countByStatus();
        Map<String, Long> byType        = requestDAO.countByType();
        List<Request>     recentAll     = requestDAO.findAllWithFilters(null, null, null, null);
        // Limit to last 5
        List<Request>     recent        = recentAll.size() > 5 ? recentAll.subList(0, 5) : recentAll;

        long totalRequests = byStatus.values().stream().mapToLong(Long::longValue).sum();

        return new AdminSummary(
            totalUsers,
            totalRequests,
            byStatus.getOrDefault("PENDING",   0L),
            byStatus.getOrDefault("APPROVED",  0L),
            byStatus.getOrDefault("REJECTED",  0L),
            byStatus.getOrDefault("CANCELLED", 0L),
            byType.getOrDefault("LEAVE",    0L),
            byType.getOrDefault("LOAN",     0L),
            byType.getOrDefault("TRAINING", 0L),
            recent
        );
    }

    // ---------------------------------------------------------------
    // Inner summary classes — simple data holders passed to JSPs
    // ---------------------------------------------------------------

    /** Summary data for the employee dashboard. */
    public static class EmployeeSummary {
        private final long pending;
        private final long approved;
        private final long rejected;
        private final long cancelled;
        private final List<Request> recentRequests;

        public EmployeeSummary(long pending, long approved, long rejected,
                               long cancelled, List<Request> recentRequests) {
            this.pending = pending;
            this.approved = approved;
            this.rejected = rejected;
            this.cancelled = cancelled;
            this.recentRequests = recentRequests;
        }

        public long getPending() { return pending; }
        public long getApproved() { return approved; }
        public long getRejected() { return rejected; }
        public long getCancelled() { return cancelled; }

        public long getTotal() {
            return pending + approved + rejected + cancelled;
        }

        public List<Request> getRecentRequests() {
            return recentRequests;
        }
    }

    /** Summary data for the manager dashboard. */
    public static class ManagerSummary {
        private final long pendingCount;
        private final long totalCount;
        private final List<Request> recentRequests;

        public ManagerSummary(long pendingCount, long totalCount, List<Request> recentRequests) {
            this.pendingCount = pendingCount;
            this.totalCount = totalCount;
            this.recentRequests = recentRequests;
        }

        public long getPendingCount() {
            return pendingCount;
        }

        public long getTotalCount() {
            return totalCount;
        }

        public List<Request> getRecentRequests() {
            return recentRequests;
        }
    }
    public static class AdminSummary {
        private final long totalUsers;
        private final long totalRequests;
        private final long pending;
        private final long approved;
        private final long rejected;
        private final long cancelled;
        private final long leaveCount;
        private final long loanCount;
        private final long trainingCount;
        private final List<Request> recentRequests;

        public AdminSummary(long totalUsers, long totalRequests,
                            long pending, long approved, long rejected, long cancelled,
                            long leaveCount, long loanCount, long trainingCount,
                            List<Request> recentRequests) {
            this.totalUsers = totalUsers;
            this.totalRequests = totalRequests;
            this.pending = pending;
            this.approved = approved;
            this.rejected = rejected;
            this.cancelled = cancelled;
            this.leaveCount = leaveCount;
            this.loanCount = loanCount;
            this.trainingCount = trainingCount;
            this.recentRequests = recentRequests;
        }

        public long getTotalUsers() { return totalUsers; }
        public long getTotalRequests() { return totalRequests; }
        public long getPending() { return pending; }
        public long getApproved() { return approved; }
        public long getRejected() { return rejected; }
        public long getCancelled() { return cancelled; }
        public long getLeaveCount() { return leaveCount; }
        public long getLoanCount() { return loanCount; }
        public long getTrainingCount() { return trainingCount; }
        public List<Request> getRecentRequests() { return recentRequests; }
    }
}
