package com.ers.util;

import com.ers.entity.Request;

/**
 * Central configuration for all email settings and HTML templates.
 * Update SMTP_HOST, SMTP_USER, and SMTP_PASSWORD to match your mail server.
 *
 * Templates use simple string replacement — no external template engine needed.
 * Each template produces a self-contained HTML email body.
 */
public class EmailConfig {

    // ---------------------------------------------------------------
    // SMTP Settings — update these before deploying
    // ---------------------------------------------------------------

    /** SMTP server hostname. Use "smtp.gmail.com" for Gmail. */
    public static final String SMTP_HOST     = "smtp.gmail.com";

    /** SMTP port. 587 for TLS (STARTTLS), 465 for SSL. */
    public static final int    SMTP_PORT     = 587;

    /** The email address used as the sender (From:). */
    public static final String SMTP_USER     = "hussainjaffer84@gmail.com";

    /**
     * The SMTP password or app-specific password.
     * For Gmail: generate an App Password at myaccount.google.com/apppasswords
     */
    public static final String SMTP_PASSWORD = "ttjgyegsplwhcqwg";

    /** Display name shown in the From: field of the email. */
    public static final String SENDER_NAME   = "Employee Request System";

    /** Whether to use TLS (STARTTLS). Should be true for port 587. */
    public static final boolean USE_TLS      = true;

    // ---------------------------------------------------------------
    // Email Templates
    // Each method returns a complete HTML email body string.
    // ---------------------------------------------------------------

    /**
     * Template for when an employee submits a new request.
     * Sent to the employee as a submission confirmation.
     *
     * @param employeeName the full name of the employee
     * @param request      the submitted request entity
     * @return HTML email body
     */
    public static String requestSubmittedBody(String employeeName, Request request) {
        return baseTemplate(
            "Request Submitted",
            "#4f46e5",
            "&#128203; Request Submitted",
            "Hello " + employeeName + ",",
            "Your request has been submitted successfully and is now awaiting review.",
            buildRequestDetails(request),
            "We will notify you once a decision has been made."
        );
    }

    /**
     * Template for when a manager approves a request.
     * Sent to the employee who owns the request.
     *
     * @param employeeName the full name of the employee
     * @param request      the approved request entity
     * @param comment      the manager's comment (may be empty)
     * @return HTML email body
     */
    public static String requestApprovedBody(String employeeName, Request request, String comment) {
        String commentSection = (comment != null && !comment.trim().isEmpty())
            ? "<p style='margin:12px 0 0; padding:12px; background:#f0fdf4; border-left:4px solid #16a34a; "
              + "border-radius:4px; color:#166534;'><strong>Manager's comment:</strong> " + comment + "</p>"
            : "";
        return baseTemplate(
            "Request Approved",
            "#16a34a",
            "&#10003; Request Approved",
            "Hello " + employeeName + ",",
            "Great news! Your request has been <strong>approved</strong>.",
            buildRequestDetails(request) + commentSection,
            "No further action is required from your side."
        );
    }

    /**
     * Template for when a manager rejects a request.
     * Sent to the employee who owns the request.
     *
     * @param employeeName the full name of the employee
     * @param request      the rejected request entity
     * @param comment      the manager's rejection reason
     * @return HTML email body
     */
    public static String requestRejectedBody(String employeeName, Request request, String comment) {
        String commentSection = (comment != null && !comment.trim().isEmpty())
            ? "<p style='margin:12px 0 0; padding:12px; background:#fef2f2; border-left:4px solid #dc2626; "
              + "border-radius:4px; color:#991b1b;'><strong>Reason:</strong> " + comment + "</p>"
            : "";
        return baseTemplate(
            "Request Rejected",
            "#dc2626",
            "&#10007; Request Rejected",
            "Hello " + employeeName + ",",
            "Unfortunately, your request has been <strong>rejected</strong>.",
            buildRequestDetails(request) + commentSection,
            "You may submit a new request or contact your manager for more information."
        );
    }

    /**
     * Template for when an employee cancels their own request.
     * Sent to the employee as a cancellation confirmation.
     *
     * @param employeeName the full name of the employee
     * @param request      the cancelled request entity
     * @return HTML email body
     */
    public static String requestCancelledBody(String employeeName, Request request) {
        return baseTemplate(
            "Request Cancelled",
            "#6b7280",
            "&#8855; Request Cancelled",
            "Hello " + employeeName + ",",
            "Your request has been <strong>cancelled</strong> as requested.",
            buildRequestDetails(request),
            "You can submit a new request at any time."
        );
    }

    // ---------------------------------------------------------------
    // Private helpers
    // ---------------------------------------------------------------

    /**
     * Builds a small HTML table showing the key request fields.
     */
    private static String buildRequestDetails(Request request) {
        StringBuilder sb = new StringBuilder();
        sb.append("<table style='width:100%; border-collapse:collapse; margin-top:12px;'>");
        addRow(sb, "Title",  request.getTitle());
        addRow(sb, "Type",   request.getType().name());
        addRow(sb, "Status", request.getStatus().name());
        if (request.getStartDate() != null)
            addRow(sb, "Start Date", request.getStartDate().toString());
        if (request.getEndDate() != null)
            addRow(sb, "End Date", request.getEndDate().toString());
        if (request.getAmount() != null)
            addRow(sb, "Amount", "BHD " + request.getAmount().toPlainString());
        sb.append("</table>");
        return sb.toString();
    }

    private static void addRow(StringBuilder sb, String label, String value) {
        sb.append("<tr>")
          .append("<td style='padding:6px 8px; color:#888; font-size:13px; width:120px;'>").append(label).append("</td>")
          .append("<td style='padding:6px 8px; font-size:13px; font-weight:600;'>").append(value).append("</td>")
          .append("</tr>");
    }

    /**
     * Wraps content in a consistent branded HTML email layout.
     */
    private static String baseTemplate(String subject, String accentColor,
                                        String heading, String greeting,
                                        String intro, String details, String footer) {
        return "<!DOCTYPE html><html><body style='margin:0;padding:0;background:#f0f2f5;font-family:Segoe UI,sans-serif;'>"
            + "<div style='max-width:560px;margin:32px auto;background:#fff;border-radius:10px;"
            + "box-shadow:0 2px 12px rgba(0,0,0,0.08);overflow:hidden;'>"
            + "<div style='background:" + accentColor + ";padding:24px 32px;'>"
            + "<h2 style='margin:0;color:#fff;font-size:20px;'>" + heading + "</h2>"
            + "</div>"
            + "<div style='padding:28px 32px;'>"
            + "<p style='margin:0 0 12px;font-size:15px;color:#1a1a2e;'>" + greeting + "</p>"
            + "<p style='margin:0 0 16px;font-size:14px;color:#555;'>" + intro + "</p>"
            + details
            + "<p style='margin:20px 0 0;font-size:13px;color:#888;'>" + footer + "</p>"
            + "</div>"
            + "<div style='padding:16px 32px;background:#f8f9fa;border-top:1px solid #eee;"
            + "font-size:12px;color:#aaa;text-align:center;'>"
            + "Employee Request System &mdash; This is an automated message, please do not reply."
            + "</div>"
            + "</div></body></html>";
    }
}
