<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s"   uri="/struts-tags" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>

<h2 style="font-size:20px; color:#1a1a2e; margin-bottom:20px;">Reports</h2>

<!-- Year selector -->
<div class="card" style="padding:14px 20px; margin-bottom:20px;">
    <s:form action="reports" method="get" theme="simple"
            style="display:flex; align-items:center; gap:12px;">
        <label style="margin:0; font-weight:600;">Year:</label>
        <s:select name="selectedYear" list="#{
            (currentYear-2):(currentYear-2),
            (currentYear-1):(currentYear-1),
            currentYear:currentYear}"
            value="%{selectedYear}" cssStyle="width:120px;"/>
        <button type="submit" class="btn btn-secondary btn-sm">Apply</button>
    </s:form>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:24px;">

    <!-- Requests by Status Chart -->
    <div class="card">
        <div class="card-title" style="margin-bottom:16px;">Requests by Status</div>
        <c:set var="maxStatus" value="1"/>
        <c:forEach var="entry" items="${byStatus}">
            <c:if test="${entry.value > maxStatus}">
                <c:set var="maxStatus" value="${entry.value}"/>
            </c:if>
        </c:forEach>
        <c:forEach var="entry" items="${byStatus}">
            <div style="margin-bottom:12px;">
                <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:4px;">
                    <span>${entry.key}</span>
                    <strong>${entry.value}</strong>
                </div>
                <div style="background:#f0f0f0; border-radius:4px; height:10px; overflow:hidden;">
                    <div style="height:100%; border-radius:4px;
                                width:${(entry.value * 100) / maxStatus}%;
                                background:${entry.key == 'PENDING'   ? '#f59e0b' :
                                             entry.key == 'APPROVED'  ? '#16a34a' :
                                             entry.key == 'REJECTED'  ? '#dc2626' : '#9ca3af'};
                                transition:width 0.4s;">
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>

    <!-- Requests by Type Chart -->
    <div class="card">
        <div class="card-title" style="margin-bottom:16px;">Requests by Type</div>
        <c:set var="maxType" value="1"/>
        <c:forEach var="entry" items="${byType}">
            <c:if test="${entry.value > maxType}">
                <c:set var="maxType" value="${entry.value}"/>
            </c:if>
        </c:forEach>
        <c:forEach var="entry" items="${byType}">
            <div style="margin-bottom:12px;">
                <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:4px;">
                    <span>${entry.key}</span>
                    <strong>${entry.value}</strong>
                </div>
                <div style="background:#f0f0f0; border-radius:4px; height:10px; overflow:hidden;">
                    <div style="height:100%; border-radius:4px;
                                width:${(entry.value * 100) / maxType}%;
                                background:${entry.key == 'LEAVE'    ? '#4f46e5' :
                                             entry.key == 'LOAN'     ? '#d97706' : '#16a34a'};
                                transition:width 0.4s;">
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>

</div>

<!-- Monthly Trend Chart -->
<div class="card" style="margin-bottom:24px;">
    <div class="card-title" style="margin-bottom:20px;">
        Monthly Requests — ${selectedYear}
    </div>

    <%-- Find max value for scaling --%>
    <c:set var="maxMonth" value="1"/>
    <c:forEach var="entry" items="${byMonth}">
        <c:if test="${entry.value > maxMonth}">
            <c:set var="maxMonth" value="${entry.value}"/>
        </c:if>
    </c:forEach>

    <div style="display:flex; align-items:flex-end; gap:8px; height:140px;">
        <c:forEach var="entry" items="${byMonth}">
            <div style="flex:1; display:flex; flex-direction:column; align-items:center; gap:4px;">
                <span style="font-size:11px; color:#888;">${entry.value}</span>
                <div style="width:100%; background:#4f46e5; border-radius:4px 4px 0 0;
                            min-height:4px;
                            height:${entry.value == 0 ? 4 : (entry.value * 110) / maxMonth}px;
                            transition:height 0.4s;">
                </div>
                <span style="font-size:11px; color:#888;">${entry.key}</span>
            </div>
        </c:forEach>
    </div>
</div>

<!-- Full Request Data Table -->
<div class="card">
    <div class="card-header">
        <span class="card-title">All Requests</span>
        <span style="font-size:13px; color:#888;">${allRequests.size()} total</span>
    </div>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Employee ID</th>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <c:choose>
                    <c:when test="${empty allRequests}">
                        <tr>
                            <td colspan="7" style="text-align:center; color:#888; padding:24px;">
                                No requests found.
                            </td>
                        </tr>
                    </c:when>
                    <c:otherwise>
                        <c:forEach var="req" items="${allRequests}" varStatus="st">
                            <tr>
                                <td style="color:#888;">${st.index + 1}</td>
                                <td>#${req.employeeId}</td>
                                <td><strong>${req.title}</strong></td>
                                <td>${req.type}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 'PENDING'}">
                                            <span class="badge badge-pending">Pending</span>
                                        </c:when>
                                        <c:when test="${req.status == 'APPROVED'}">
                                            <span class="badge badge-approved">Approved</span>
                                        </c:when>
                                        <c:when test="${req.status == 'REJECTED'}">
                                            <span class="badge badge-rejected">Rejected</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-cancelled">Cancelled</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>${req.createdAt}</td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/viewRequest?id=${req.id}"
                                       class="btn btn-secondary btn-sm">View</a>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:otherwise>
                </c:choose>
            </tbody>
        </table>
    </div>
</div>
