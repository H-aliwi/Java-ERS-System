package com.ers.action;

import com.ers.entity.Department;
import com.ers.entity.User;
import com.ers.enums.Role;
import com.ers.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.interceptor.SessionAware;

import java.util.List;
import java.util.Map;

/**
 * Action class for Admin employee management.
 * Each public method maps to one URL in struts.xml.
 *
 * list()   → GET  /employees       → show paginated employee table
 * add()    → GET  /addEmployee     → show blank add form
 * save()   → POST /saveEmployee    → insert new employee
 * edit()   → GET  /editEmployee    → show pre-filled edit form
 * update() → POST /updateEmployee  → save changes to existing employee
 * delete() → GET  /deleteEmployee  → soft-delete employee
 */
public class EmployeeAction extends ActionSupport implements SessionAware {

    private static final Logger logger = LogManager.getLogger(EmployeeAction.class);

    private final UserService userService = new UserService();

    // Session map injected by Struts via SessionAware
    private Map<String, Object> session;

    // --- Data passed to JSPs via getters ---
    private List<User>       employees;
    private List<Department> departments;
    private User             employee;       // single employee for add/edit forms
    private int              currentPage = 1;
    private int              totalPages;
    private long             totalCount;
    private String           searchKeyword;

    // Used on edit form: new password is optional
    private String newPassword;

    // The ID of the employee to edit or delete (from URL parameter)
    private Long id;

    // ---------------------------------------------------------------
    // list() — shows the paginated employee table
    // ---------------------------------------------------------------

    /**
     * Loads all active employees with pagination.
     * If searchKeyword is provided, filters by name/username instead.
     *
     * @return SUCCESS → employees.jsp
     */
    public String list() {
        if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
            employees = userService.searchEmployees(searchKeyword.trim());
            totalPages = 1;
            totalCount = employees.size();
        } else {
            employees  = userService.getAllEmployees(currentPage);
            totalPages = userService.getTotalPages();
            totalCount = userService.getTotalEmployeeCount();
        }
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    // add() — shows the blank add employee form
    // ---------------------------------------------------------------

    /**
     * Prepares an empty User and loads departments for the dropdown.
     *
     * @return SUCCESS → addEmployee.jsp
     */
    public String add() {
        employee    = new User();
        departments = userService.getDepartments();
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    // save() — processes the add employee form submission
    // ---------------------------------------------------------------

    /**
     * Validates and saves a new employee.
     * On validation failure, reloads the form with error messages.
     *
     * @return SUCCESS → redirect to employee list
     *         INPUT   → addEmployee.jsp with errors
     */
    public String save() {
        // Server-side validation
        if (employee.getUsername() == null || employee.getUsername().trim().isEmpty()) {
            addFieldError("employee.username", "Username is required.");
        }
        if (employee.getFullName() == null || employee.getFullName().trim().isEmpty()) {
            addFieldError("employee.fullName", "Full name is required.");
        }
        if (employee.getEmail() == null || employee.getEmail().trim().isEmpty()) {
            addFieldError("employee.email", "Email is required.");
        } else if (!employee.getEmail().matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$")) {
            addFieldError("employee.email", "Please enter a valid email address.");
        }
        if (employee.getPassword() == null || employee.getPassword().trim().length() < 6) {
            addFieldError("employee.password", "Password must be at least 6 characters.");
        }
        if (employee.getRole() == null) {
            addFieldError("employee.role", "Role is required.");
        }

        if (hasFieldErrors()) {
            departments = userService.getDepartments();
            return INPUT;
        }

        try {
            userService.createEmployee(employee);
            addActionMessage("Employee '" + employee.getFullName() + "' created successfully.");
            return SUCCESS;
        } catch (IllegalArgumentException e) {
            addActionError(e.getMessage());
            departments = userService.getDepartments();
            return INPUT;
        }
    }

    // ---------------------------------------------------------------
    // edit() — shows the pre-filled edit form
    // ---------------------------------------------------------------

    /**
     * Loads the employee by ID and prepares the edit form.
     *
     * @return SUCCESS → editEmployee.jsp
     *         ERROR   → error page if employee not found
     */
    public String edit() {
        employee = userService.getEmployeeById(id);
        if (employee == null) {
            addActionError("Employee not found.");
            return ERROR;
        }
        departments = userService.getDepartments();
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    // update() — processes the edit employee form submission
    // ---------------------------------------------------------------

    /**
     * Validates and saves changes to an existing employee.
     *
     * @return SUCCESS → redirect to employee list
     *         INPUT   → editEmployee.jsp with errors
     */
    public String update() {
        if (employee.getFullName() == null || employee.getFullName().trim().isEmpty()) {
            addFieldError("employee.fullName", "Full name is required.");
        }
        if (employee.getEmail() == null || employee.getEmail().trim().isEmpty()) {
            addFieldError("employee.email", "Email is required.");
        } else if (!employee.getEmail().matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$")) {
            addFieldError("employee.email", "Please enter a valid email address.");
        }
        if (newPassword != null && !newPassword.trim().isEmpty() && newPassword.trim().length() < 6) {
            addFieldError("newPassword", "New password must be at least 6 characters.");
        }

        if (hasFieldErrors()) {
            departments = userService.getDepartments();
            return INPUT;
        }

        try {
            // Load existing hash so we can preserve it if no new password is given
            User existing = userService.getEmployeeById(employee.getId());
            if (existing == null) {
                addActionError("Employee not found.");
                return ERROR;
            }
            userService.updateEmployee(employee, newPassword, existing.getPassword());
            addActionMessage("Employee updated successfully.");
            return SUCCESS;
        } catch (IllegalArgumentException e) {
            addActionError(e.getMessage());
            departments = userService.getDepartments();
            return INPUT;
        }
    }

    // ---------------------------------------------------------------
    // delete() — soft-deletes an employee
    // ---------------------------------------------------------------

    /**
     * Deactivates the employee with the given ID.
     * Redirects back to the employee list with a confirmation message.
     *
     * @return SUCCESS → redirect to employee list
     */
    public String delete() {
        try {
            userService.deleteEmployee(id);
            addActionMessage("Employee deactivated successfully.");
        } catch (Exception e) {
            addActionError("Could not deactivate employee. Please try again.");
            logger.error("Error deactivating employee id={}", id, e);
        }
        return SUCCESS;
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    // --- Getters for JSPs ---
    public List<User>       getEmployees()     { return employees; }
    public List<Department> getDepartments()   { return departments; }
    public User             getEmployee()      { return employee; }
    public int              getCurrentPage()   { return currentPage; }
    public int              getTotalPages()    { return totalPages; }
    public long             getTotalCount()    { return totalCount; }
    public String           getSearchKeyword() { return searchKeyword; }
    public Role[]           getRoles()         { return Role.values(); }

    // --- Setters for Struts parameter binding ---
    public void setEmployee(User employee)           { this.employee = employee; }
    public void setCurrentPage(int currentPage)      { this.currentPage = currentPage; }
    public void setSearchKeyword(String searchKeyword){ this.searchKeyword = searchKeyword; }
    public void setNewPassword(String newPassword)   { this.newPassword = newPassword; }
    public void setId(Long id)                       { this.id = id; }
    public Long getId()                              { return id; }
}
