<%@ page contentType="text/html;charset=UTF-8" %>
<%-- Immediately redirect to the login action when the root URL is accessed --%>
<% response.sendRedirect(request.getContextPath() + "/login"); %>
