package com.ers.entity;

import com.ers.enums.ActionType;
import java.time.LocalDateTime;

/**
 * Plain POJO representing a row in the "request_actions" table.
 * No JPA/Hibernate annotations — mapped manually in RequestActionDAO.
 */
public class RequestAction {

    private Long id;
    private Long requestId;
    private Long actionBy;
    private ActionType action;
    private String comment;
    private LocalDateTime actionDate;

    // --- Constructors ---

    public RequestAction() {}

    public RequestAction(Long requestId, Long actionBy, ActionType action, String comment) {
        this.requestId = requestId;
        this.actionBy = actionBy;
        this.action = action;
        this.comment = comment;
    }

    // --- Getters and Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }

    public Long getActionBy() { return actionBy; }
    public void setActionBy(Long actionBy) { this.actionBy = actionBy; }

    public ActionType getAction() { return action; }
    public void setAction(ActionType action) { this.action = action; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public LocalDateTime getActionDate() { return actionDate; }
    public void setActionDate(LocalDateTime actionDate) { this.actionDate = actionDate; }
}
