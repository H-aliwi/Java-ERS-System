package com.ers.dao;

import com.ers.entity.User;
import com.ers.enums.Role;
import com.ers.util.DatabaseConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private static final Logger logger = LogManager.getLogger(UserDAO.class);

    private Connection getConnection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    // ================= SAVE =================
    public void save(User u) {
        String sql = "INSERT INTO users (username, full_name, email, password, role, department_id, is_active, created_at) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, u.getUsername());
            stmt.setString(2, u.getFullName());
            stmt.setString(3, u.getEmail());
            stmt.setString(4, u.getPassword());
            stmt.setObject(5, u.getRole(), java.sql.Types.OTHER);
            stmt.setObject(6, u.getDepartmentId());
            stmt.setBoolean(7, u.isActive());
            stmt.setTimestamp(8, Timestamp.valueOf(u.getCreatedAt() != null ? u.getCreatedAt() : LocalDateTime.now()));

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        u.setId(rs.getLong(1));
                    }
                }
            }

            logger.debug("User saved: {}", u.getUsername());
        } catch (Exception e) {
            logger.error("Error saving user {}: {}", u.getUsername(), e.getMessage(), e);
            throw new RuntimeException("Could not save user", e);
        }
    }

    // ================= UPDATE =================
    public void update(User u) {
        String sql = "UPDATE users SET username=?, full_name=?, email=?, password=?, role=?, department_id=?, is_active=? WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, u.getUsername());
            stmt.setString(2, u.getFullName());
            stmt.setString(3, u.getEmail());
            stmt.setString(4, u.getPassword());
            stmt.setObject(5, u.getRole(), java.sql.Types.OTHER);
            stmt.setObject(6, u.getDepartmentId());
            stmt.setBoolean(7, u.isActive());
            stmt.setLong(8, u.getId());

            int affected = stmt.executeUpdate();
            logger.debug("User updated: {} (rows: {})", u.getUsername(), affected);

        } catch (Exception e) {
            logger.error("Error updating user {}: {}", u.getUsername(), e.getMessage(), e);
            throw new RuntimeException("Could not update user", e);
        }
    }

    // ================= DELETE =================
    public void delete(Long id) {
        String sql = "DELETE FROM users WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            int affected = stmt.executeUpdate();
            logger.debug("User deleted: id={} (rows: {})", id, affected);

        } catch (Exception e) {
            logger.error("Error deleting user id={}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Could not delete user", e);
        }
    }

    // ================= FIND BY ID =================
    public User findById(Long id) {
        String sql = "SELECT * FROM users WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapUser(rs);
                }
            }

        } catch (Exception e) {
            logger.error("Error finding user by id={}: {}", id, e.getMessage(), e);
        }

        return null;
    }

    // ================= FIND ALL =================
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapUser(rs));
            }

        } catch (Exception e) {
            logger.error("Error fetching all users: {}", e.getMessage(), e);
        }

        return list;
    }

    // ================= CUSTOM METHODS =================

    public User findByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username=? AND is_active=true";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapUser(rs);
                }
            }

        } catch (Exception e) {
            logger.error("Error finding user by username {}: {}", username, e.getMessage(), e);
        }

        return null;
    }

    public List<User> findByRole(Role role) {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE role=? AND is_active=true ORDER BY full_name";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, role.name());
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapUser(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding users by role {}: {}", role, e.getMessage(), e);
        }

        return list;
    } 

    public List<User> findAllActive() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE is_active=true ORDER BY full_name";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapUser(rs));
            }

        } catch (Exception e) {
            logger.error("Error fetching all is_active users: {}", e.getMessage(), e);
        }

        return list;
    }

    public void deactivate(Long id) {
        String sql = "UPDATE users SET is_active=false WHERE id=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            int affected = stmt.executeUpdate();
            logger.debug("User deactivated: id={} (rows: {})", id, affected);

        } catch (Exception e) {
            logger.error("Error deactivating user id={}: {}", id, e.getMessage(), e);
            throw new RuntimeException("Could not deactivate user", e);
        }
    }

    public boolean usernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username=?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong(1) > 0;
                }
            }

        } catch (Exception e) {
            logger.error("Error checking username exists {}: {}", username, e.getMessage(), e);
        }

        return false;
    }

    // ================= HELPER =================
    private User mapUser(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getLong("id"));
        u.setUsername(rs.getString("username"));
        u.setFullName(rs.getString("full_name"));
        u.setEmail(rs.getString("email"));
        u.setPassword(rs.getString("password"));
        u.setRole(Role.valueOf(rs.getString("role")));
        u.setDepartmentId(rs.getObject("department_id", Long.class));
        u.setActive(rs.getBoolean("is_active"));
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            u.setCreatedAt(createdAt.toLocalDateTime());
        }
        return u;
    }
}