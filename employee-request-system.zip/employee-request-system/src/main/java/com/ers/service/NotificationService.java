package com.ers.service;

import com.ers.dao.NotificationDAO;
import com.ers.entity.Notification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * Service class for in-app notification management.
 * Called by RequestService after every status change to create a notification
 * that appears in the header bell icon.
 */
public class NotificationService {

    private static final Logger logger = LogManager.getLogger(NotificationService.class);

    private final NotificationDAO notificationDAO = new NotificationDAO();

    /**
     * Creates and persists a new in-app notification for a user.
     * Called after every request status change.
     *
     * @param userId  the ID of the user who should receive the notification
     * @param message the notification message text
     */
    public void createNotification(Long userId, String message) {
        try {
            Notification notif = new Notification(userId, message);
            notificationDAO.save(notif);
            logger.debug("Notification created for userId={}: {}", userId, message);
        } catch (Exception e) {
            // Log but don't crash — notification failure must never block the main operation
            logger.error("Failed to create notification for userId={}", userId, e);
        }
    }

    /**
     * Returns the count of unread notifications for a user.
     * Used by the AJAX polling endpoint to update the bell badge.
     *
     * @param userId the user's primary key
     * @return number of unread notifications
     */
    public long getUnreadCount(Long userId) {
        return notificationDAO.findUnread(userId).size();
    }

    /**
     * Returns the 5 most recent notifications for a user.
     * Used to populate the notification dropdown in the header.
     *
     * @param userId the user's primary key
     * @return list of up to 5 recent notifications
     */
    public List<Notification> getRecentNotifications(Long userId) {
        List<Notification> all = notificationDAO.findByUser(userId);
        return all.size() > 5 ? all.subList(0, 5) : all;
    }

    /**
     * Returns all notifications for a user.
     *
     * @param userId the user's primary key
     * @return full list of notifications
     */
    public List<Notification> getUserNotifications(Long userId) {
        return notificationDAO.findByUser(userId);
    }

    /**
     * Marks a single notification as read.
     *
     * @param id the notification's primary key
     */
    public void markAsRead(Long id) {
        notificationDAO.markAsRead(id);
    }

    /**
     * Marks all notifications for a user as read.
     *
     * @param userId the user's primary key
     */
    public void markAllAsRead(Long userId) {
        notificationDAO.markAllAsRead(userId);
    }
}
