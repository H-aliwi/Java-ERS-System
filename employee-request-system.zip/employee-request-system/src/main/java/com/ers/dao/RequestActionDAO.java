package com.ers.dao;

import com.ers.entity.RequestAction;
import com.ers.enums.ActionType;
import com.ers.util.DatabaseConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * DAO for the request_actions table.
 */
public class RequestActionDAO {

    private static final Logger logger = LogManager.getLogger(RequestActionDAO.class);

    private Connection getConnection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    // ================= SAVE =================
    public void save(RequestAction ra) {
        String sql = "INSERT INTO request_actions (request_id, action_by, action, comment, action_date) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.NO_GENERATED_KEYS)) {

            stmt.setLong(1, ra.getRequestId());
            stmt.setLong(2, ra.getActionBy());
            stmt.setObject(3, ra.getAction(), java.sql.Types.OTHER);
            stmt.setString(4, ra.getComment());
            stmt.setTimestamp(5, Timestamp.valueOf(ra.getActionDate() != null ? ra.getActionDate() : LocalDateTime.now()));

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        ra.setId(rs.getLong(1));
                    }
                }
            }

            logger.debug("RequestAction saved: requestId={}", ra.getRequestId());
        } catch (Exception e) {
            logger.error("Error saving request action: {}", e.getMessage(), e);
            throw new RuntimeException("Could not save request action", e);
        }
    }

    // ================= FIND BY REQUEST =================
    public List<RequestAction> findByRequest(Long requestId) {
        List<RequestAction> list = new ArrayList<>();
        String sql = "SELECT * FROM request_actions WHERE request_id=? ORDER BY action_date ASC";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRequestAction(rs));
                }
            }

        } catch (Exception e) {
            logger.error("Error finding actions for request {}: {}", requestId, e.getMessage(), e);
        }

        return list;
    }

    // ================= HELPER =================
    private RequestAction mapRequestAction(ResultSet rs) throws SQLException {
        RequestAction ra = new RequestAction();
        ra.setId(rs.getLong("id"));
        ra.setRequestId(rs.getLong("request_id"));
        ra.setActionBy(rs.getLong("action_by"));
        ra.setAction(ActionType.valueOf(rs.getString("action")));
        ra.setComment(rs.getString("comment"));
        Timestamp actionDate = rs.getTimestamp("action_date");
        if (actionDate != null) {
            ra.setActionDate(actionDate.toLocalDateTime());
        }
        return ra;
    }
}
