<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access Denied</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5;
               display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .box { background: #fff; border-radius: 10px; padding: 40px; text-align: center;
               box-shadow: 0 4px 20px rgba(0,0,0,0.1); max-width: 400px; }
        h2 { color: #e53e3e; margin-bottom: 12px; }
        p  { color: #666; margin-bottom: 24px; }
        a  { color: #4f46e5; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Access Denied</h2>
        <p>You do not have permission to view this page.</p>
        <a href="${pageContext.request.contextPath}/login">Back to Login</a>
    </div>
</body>
</html>
