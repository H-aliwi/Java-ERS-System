<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="tiles" uri="http://tiles.apache.org/tags-tiles" %>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <span><tiles:insertAttribute name="title"/></span>

     <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">

</head>

<body>

<div class="wrapper">

    <!-- ===== SIDEBAR ===== -->
    <aside class="sidebar">
        <div class="sidebar-brand">ERS System</div>

        <ul class="sidebar-menu">

            <c:if test="${sessionScope.role == 'EMPLOYEE'}">
                <li><a href="${pageContext.request.contextPath}/home">Dashboard</a></li>
                <li><a href="${pageContext.request.contextPath}/myRequests">My Requests</a></li>
                <li><a href="${pageContext.request.contextPath}/newRequest">New Request</a></li>
            </c:if>

            <c:if test="${sessionScope.role == 'MANAGER'}">
                <li><a href="${pageContext.request.contextPath}/managerDashboard">Dashboard</a></li>
                <li><a href="${pageContext.request.contextPath}/departmentRequests">Department Requests</a></li>
            </c:if>

            <c:if test="${sessionScope.role == 'ADMIN'}">
                <li><a href="${pageContext.request.contextPath}/adminDashboard">Dashboard</a></li>
                <li><a href="${pageContext.request.contextPath}/employees">Employees</a></li>
                <li><a href="${pageContext.request.contextPath}/allRequests">All Requests</a></li>
                <li><a href="${pageContext.request.contextPath}/reports">Reports</a></li>
            </c:if>

          </ul>

          <!-- Logout at bottom of sidebar -->
          <ul class="sidebar-menu main-menu">
              <li><a href="${pageContext.request.contextPath}/logout" class="logout-link"> Logout</a></li>
          </ul>

      </aside>

    <!-- ===== MAIN ===== -->
    <div class="main-content">

         <header class="topbar">
              <span>${title}</span>

             <div class="topbar-right">

                 <!-- Notifications -->
                 <div class="notif-wrapper">
                     <div class="notif-bell" onclick="toggleNotifDropdown()">🔔
                         <span class="notif-badge" id="notifBadge" style="display:none;">0</span>
                     </div>

                     <div class="notif-dropdown" id="notifDropdown">
                         <div class="notif-header">
                             <span>Notifications</span>
                             <a onclick="markAllRead()">Mark all read</a>
                         </div>
                         <div class="notif-list" id="notifList">
                             <div class="notif-empty">Loading...</div>
                         </div>
                     </div>
                 </div>

                 <!-- User Info & Logout -->
                 <div class="user-info">
                     <span class="user-name">
                         Hello ${sessionScope.fullName}
                     </span>
                     <c:choose>
                         <c:when test="${sessionScope.role == 'ADMIN'}">
                             <span class="user-role badge-admin">ADMIN</span>
                         </c:when>
                         <c:when test="${sessionScope.role == 'MANAGER'}">
                             <span class="user-role badge-manager">MANAGER</span>
                         </c:when>
                         <c:otherwise>
                             <span class="user-role badge-employee">EMPLOYEE</span>
                         </c:otherwise>
                     </c:choose>
                 </div>

             </div>
         </header>

        <main class="page-body">
            <tiles:insertAttribute name="content" />
            
        </main>

    </div>
</div>

<script>
const CTX = '${pageContext.request.contextPath}';

function updateBadge(count) {
    const badge = document.getElementById('notifBadge');
    if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'inline-block';
    } else {
        badge.style.display = 'none';
    }
}

function toggleNotifDropdown() {
    const d = document.getElementById('notifDropdown');
    d.classList.toggle('open');
    if (d.classList.contains('open')) {
        fetchNotifications();
    }
}

function fetchNotifications() {
    fetch(CTX + '/getUnreadNotifications')
    .then(r => r.json())
    .then(data => {
        updateBadge(data.unreadCount);
        populateNotifications(data.notifications);
    })
    .catch(err => {
        console.error('Failed to fetch notifications:', err);
        document.getElementById('notifList').innerHTML =
            '<div class="notif-empty">Error loading notifications</div>';
    });
}

function populateNotifications(notifications) {
    const list = document.getElementById('notifList');
    if (!notifications || notifications.length === 0) {
        list.innerHTML = '<div class="notif-empty">No notifications</div>';
        return;
    }

     const html = notifications.map(n => {
         const escapedMsg = n.message.replace(/[&<>"']/g, function(m) {
             return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
         });
         const timeAgo = formatTime(n.createdAt);
         return '<div class="notif-item ' + (n.read ? '' : 'unread') + '" data-id="' + n.id + '" onclick="markRead(' + n.id + ')">' +
                '<div class="notif-msg">' + escapedMsg + '</div>' +
                '<div class="notif-time">' + timeAgo + '</div>' +
                '</div>';
     }).join('');
    list.innerHTML = html;
}

function markRead(id) {
    fetch(CTX + '/markNotificationRead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + encodeURIComponent(id)
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            // Remove unread styling from this item
            const item = document.querySelector(`.notif-item[data-id="${id}"]`);
            if (item) item.classList.remove('unread');
            // Refresh badge count
            fetchNotifications();
        }
    });
}

function markAllRead() {
    fetch(CTX + '/markAllNotificationsRead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            fetchNotifications();
        }
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatTime(isoString) {
    if (!isoString) return '';
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return diffMins + 'm ago';
    if (diffHours < 24) return diffHours + 'h ago';
    if (diffDays < 7) return diffDays + 'd ago';
    return date.toLocaleDateString();
}

// Auto-refresh every 30 seconds
setInterval(fetchNotifications, 30000);
// Initial load
fetchNotifications();
</script>

</body>
</html>