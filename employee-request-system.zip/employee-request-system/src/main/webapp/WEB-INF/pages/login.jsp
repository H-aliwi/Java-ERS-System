<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Employee Request System</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f2f5;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .login-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            padding: 40px;
            width: 100%;
            max-width: 400px;
        }

        .login-card h1 {
            font-size: 22px;
            color: #1a1a2e;
            margin-bottom: 6px;
        }

        .login-card p.subtitle {
            font-size: 13px;
            color: #888;
            margin-bottom: 28px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #444;
            margin-bottom: 6px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.2s;
            outline: none;
        }

        input:focus { border-color: #4f46e5; }

        .input-error { border-color: #e53e3e !important; }

        .field-error {
            color: #e53e3e;
            font-size: 12px;
            margin-top: 4px;
            display: none;
        }

        .alert-error {
            background: #fff5f5;
            border: 1px solid #fed7d7;
            color: #c53030;
            border-radius: 6px;
            padding: 10px 14px;
            font-size: 13px;
            margin-bottom: 18px;
        }

        .btn-login {
            width: 100%;
            padding: 11px;
            background: #4f46e5;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-login:hover { background: #4338ca; }

        /* ===== INFO SECTION ===== */
        .login-info {
            margin-top: 20px;
            padding: 12px;
            background: #f8f9fa;
            border-radius: 6px;
            font-size: 11px;
            color: #666;
            line-height: 1.8;
        }

        .login-info-header {
            font-weight: 600;
            color: #444;
            font-size: 12px;
            margin-bottom: 6px;
        }

        .login-info-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .login-info-item {
            display: flex;
            align-items: baseline;
            gap: 6px;
        }

        .login-role {
            font-weight: 600;
            color: #333;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 11px;
            min-width: 70px;
        }

        .login-separator {
            color: #aaa;
            font-size: 10px;
        }

        .login-pass {
            color: #555;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 11px;
        }

        .login-note {
            margin-top: 8px;
            font-size: 10px;
            color: #999;
            font-style: italic;
        }
    </style>
</head>
<body>

<div class="login-card">
    <h1>Employee Request System</h1>
    <p class="subtitle">Sign in to your account</p>

    <%-- Server-side error from LoginAction.addActionError() --%>
    <s:if test="hasActionErrors()">
        <div class="alert-error">
            <s:actionerror/>
        </div>
    </s:if>

    <%--
        action="login" maps to the login action in struts.xml.
        method="post" sends credentials securely in the request body.
    --%>
    <s:form action="login" method="post" id="loginForm" theme="simple">

        <div class="form-group">
            <label for="username">Username</label>
            <s:textfield name="username" id="username" cssClass="form-input"
                         placeholder="Enter your username" maxlength="50"/>
            <div class="field-error" id="usernameError">Username is required.</div>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <s:password name="password" id="password" cssClass="form-input"
                        placeholder="Enter your password" maxlength="100"/>
            <div class="field-error" id="passwordError">Password is required.</div>
        </div>

         <button type="submit" class="btn-login" onclick="return validateForm()">Sign In</button>

         <div class="login-info">
            <div class="login-info-header">Demo Accounts</div>
            <div class="login-info-list">
                <div class="login-info-item">
                    <span class="login-role">admin1</span>
                    <span class="login-separator">:</span>
                    <span class="login-pass">admin123</span>
                </div>
                <div class="login-info-item">
                    <span class="login-role">manager1</span>
                    <span class="login-separator">:</span>
                    <span class="login-pass">manager123</span>
                </div>
                <div class="login-info-item">
                    <span class="login-role">emp1</span>
                    <span class="login-separator">:</span>
                    <span class="login-pass">emp123</span>
                </div>
            </div>        </div>

    </s:form>
</div>

<script>
    /**
     * Client-side validation before form submission.
     * Prevents empty form submissions from reaching the server.
     * Server-side validation in LoginAction is the authoritative check.
     */
    function validateForm() {
        let valid = true;

        const username = document.getElementById('username');
        const password = document.getElementById('password');
        const usernameError = document.getElementById('usernameError');
        const passwordError = document.getElementById('passwordError');

        // Reset previous errors
        username.classList.remove('input-error');
        password.classList.remove('input-error');
        usernameError.style.display = 'none';
        passwordError.style.display = 'none';

        if (!username.value.trim()) {
            username.classList.add('input-error');
            usernameError.style.display = 'block';
            valid = false;
        }

        if (!password.value.trim()) {
            password.classList.add('input-error');
            passwordError.style.display = 'block';
            valid = false;
        }

        return valid;
    }
</script>

</body>
</html>
