package com.ers.action;

import com.ers.entity.Request;
import com.ers.entity.RequestAction;
import com.ers.service.RequestService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.interceptor.SessionAware;

import java.util.List;
import java.util.Map;

/**
 * Struts Action class for manager request review operations.
 *
 * departmentRequests() → list all requests in the manager's department
 * review()             → show a single request for approve/reject
 * approve()            → approve the request with a comment
 * reject()             → reject the request with a comment
 */
public class ManagerAction extends ActionSupport implements SessionAware {

    private static final Logger logger = LogManager.getLogger(ManagerAction.class);

    private final RequestService requestService = new RequestService();
    private Map<String, Object> session;

    // --- Data passed to JSPs ---
    private List<Request>       requests;
    private Request             request;
    private List<RequestAction> actionHistory;
    private Long                id;
    private String              comment;

    // ---------------------------------------------------------------
    // departmentRequests() — list all requests in manager's department
    // ---------------------------------------------------------------
    public String departmentRequests() {
        Long departmentId = (Long) session.get("departmentId");
        if (departmentId == null) {
            addActionError("You are not assigned to a department.");
            return ERROR;
        }
        requests = requestService.getDepartmentRequests(departmentId);
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    // review() — load a request for the manager to review
    // ---------------------------------------------------------------
    public String review() {
    	logger.info("DEBUG action class={} method=review", this.getClass().getName());
    	logger.info("DEBUG review() id param -> {}", id);

        request = requestService.getRequestById(id);
        if (request == null) {
            addActionError("Request not found.");
            return ERROR;
        }
        actionHistory = requestService.getRequestActions(id);
        return SUCCESS;
    }

    // ---------------------------------------------------------------
    // approve() — approve the request
    // ---------------------------------------------------------------
    public String approve() {
        Long managerId = (Long) session.get("userId");
        try {
            requestService.approveRequest(id, managerId, comment);
            addActionMessage("Request approved successfully.");
            return SUCCESS;
        } catch (IllegalStateException | IllegalArgumentException e) {
            addActionError(e.getMessage());
            return ERROR;
        } catch (Exception e) {
            addActionError("Could not approve request. Please try again.");
            logger.error("Error approving request id={}", id, e);
            return ERROR;
        }
    }

    // ---------------------------------------------------------------
    // reject() — reject the request
    // ---------------------------------------------------------------
    public String reject() {
        Long managerId = (Long) session.get("userId");
        if (comment == null || comment.trim().isEmpty()) {
            addActionError("A comment is required when rejecting a request.");
            // Reload the request for the form
            request = requestService.getRequestById(id);
            actionHistory = requestService.getRequestActions(id);
            return INPUT;
        }
        try {
            requestService.rejectRequest(id, managerId, comment);
            addActionMessage("Request rejected.");
            return SUCCESS;
        } catch (IllegalStateException | IllegalArgumentException e) {
            addActionError(e.getMessage());
            return ERROR;
        } catch (Exception e) {
            addActionError("Could not reject request. Please try again.");
            logger.error("Error rejecting request id={}", id, e);
            return ERROR;
        }
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    // --- Getters for JSPs ---
    public List<Request>       getRequests()      { return requests; }
    public Request             getRequest()       { return request; }
    public List<RequestAction> getActionHistory() { return actionHistory; }
    public Long                getId()            { return id; }
    public String              getComment()       { return comment; }

    // --- Setters ---
    public void setId(Long id)           { this.id = id; }
    public void setComment(String c)     { this.comment = c; }
}
