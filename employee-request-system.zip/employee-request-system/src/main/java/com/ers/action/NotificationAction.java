package com.ers.action;

import com.ers.entity.Notification;
import com.ers.service.NotificationService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.interceptor.SessionAware;

import java.util.List;
import java.util.Map;

/**
 * Action class for notification AJAX endpoints.
 * Returns JSON responses consumed by the notification bell in layout.jsp.
 *
 * getUnread()   → GET  /getUnreadNotifications  → JSON: {count, notifications[]}
 * markRead()    → POST /markNotificationRead    → JSON: {success: true}
 * markAllRead() → POST /markAllNotificationsRead → JSON: {success: true}
 *
 * Uses the Struts 2 JSON plugin — fields exposed via getters are serialized automatically.
 */
public class NotificationAction extends ActionSupport implements SessionAware {

    private final NotificationService notificationService = new NotificationService();
    private Map<String, Object> session;

    // Fields serialized to JSON by the Struts JSON plugin
    private long               unreadCount;
    private List<Notification> notifications;
    private boolean            success;

    // Parameter for markRead — the notification ID to mark
    private Long id;

    /**
     * Returns the unread notification count and the 5 most recent notifications.
     * Called by AJAX every 30 seconds from layout.jsp.
     *
     * @return SUCCESS → JSON response
     */
    public String getUnread() {
        Long userId = (Long) session.get("userId");
        unreadCount   = notificationService.getUnreadCount(userId);
        notifications = notificationService.getRecentNotifications(userId);
        return SUCCESS;
    }

    /**
     * Marks a single notification as read.
     * Called when the user clicks a notification in the dropdown.
     *
     * @return SUCCESS → JSON {success: true}
     */
    public String markRead() {
        notificationService.markAsRead(id);
        success = true;
        return SUCCESS;
    }

    /**
     * Marks all notifications for the logged-in user as read.
     * Called when the user clicks "Mark all as read".
     *
     * @return SUCCESS → JSON {success: true}
     */
    public String markAllRead() {
        Long userId = (Long) session.get("userId");
        notificationService.markAllAsRead(userId);
        success = true;
        return SUCCESS;
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) { this.session = session; }

    // --- Getters serialized to JSON ---
    public long               getUnreadCount()   { return unreadCount; }
    public List<Notification> getNotifications() { return notifications; }
    public boolean            isSuccess()        { return success; }

    // --- Setter for id parameter ---
    public void setId(Long id) { this.id = id; }
    public Long getId()        { return id; }
}
