<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="s" uri="/struts-tags" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<div style="max-width:760px;">

    <!-- Page Header -->
    <div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
        <a href="${pageContext.request.contextPath}/employees"
           class="btn btn-secondary btn-sm">&#8592; Back</a>
        <h2 style="font-size:20px; color:#1a1a2e;">Edit Employee</h2>
    </div>

    <s:if test="hasActionErrors()">
        <div class="alert alert-error"><s:actionerror/></div>
    </s:if>

    <div class="card">
        <%--
            action="updateEmployee" → maps to EmployeeAction.update() in struts.xml
            employee.id is a hidden field so Struts knows which record to update
        --%>
        <s:form action="updateEmployee" method="post" theme="simple" id="editForm">
            <s:hidden name="employee.id"/>

            <div class="form-grid">

                <!-- Full Name -->
                <div class="form-group">
                    <label>Full Name <span class="required">*</span></label>
                    <s:textfield name="employee.fullName" id="fullName" maxlength="100"/>
                    <s:fielderror fieldName="employee.fullName" cssClass="field-error-msg"/>
                </div>
   								 <s:hidden name="employee.username" />

                <!-- Username (read-only — cannot change username after creation) -->
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" value="${employee.username}" readonly
                           style="background:#f5f5f5; color:#888;"/>
                    <small style="color:#888; font-size:11px;">Username cannot be changed.</small>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label>Email <span class="required">*</span></label>
                    <s:textfield name="employee.email" id="email" maxlength="100"/>
                    <s:fielderror fieldName="employee.email" cssClass="field-error-msg"/>
                </div>

                <!-- Phone -->
                <div class="form-group">
                    <label>Phone</label>
                    <s:textfield name="employee.phone" id="phone" maxlength="20"/>
                </div>

                <!-- New Password (optional) -->
                <div class="form-group">
                    <label>New Password</label>
                    <s:password name="newPassword" id="newPassword" maxlength="100"
                                placeholder="Leave blank to keep current password"/>
                    <s:fielderror fieldName="newPassword" cssClass="field-error-msg"/>
                    <small style="color:#888; font-size:11px;">
                        Only fill this if you want to change the password.
                    </small>
                </div>

                <!-- Role -->
                <div class="form-group">
                    <label>Role <span class="required">*</span></label>
                    <s:select name="employee.role" id="role"
                              list="roles" listKey="name()" listValue="name()"/>
                    <s:fielderror fieldName="employee.role" cssClass="field-error-msg"/>
                </div>

                <!-- Department -->
                <div class="form-group">
                    <label>Department</label>
                    <s:select name="employee.departmentId" id="departmentId"
                              list="departments" listKey="id" listValue="name"
                              headerKey="" headerValue="-- No Department --"/>
                </div>

                <!-- Active Status -->
                <div class="form-group">
                    <label>Status</label>
                    <s:select name="employee.active" id="isActive"
                              list="#{'true':'Active', 'false':'Inactive'}"/>
                </div>

            </div>

            <div style="display:flex; gap:10px; margin-top:8px;">
                <button type="submit" class="btn btn-primary" onclick="return validateEditForm()">
                    Save Changes
                </button>
                <a href="${pageContext.request.contextPath}/employees" class="btn btn-secondary">
                    Cancel
                </a>
            </div>

        </s:form>
    </div>
</div>

<script>
    function validateEditForm() {
        let valid = true;
        document.querySelectorAll('.client-error').forEach(el => el.remove());

        const fullName = document.getElementById('fullName');
        if (!fullName.value.trim()) {
            appendError(fullName, 'Full name is required.');
            valid = false;
        }

        const email = document.getElementById('email');
        if (!email.value.trim()) {
            appendError(email, 'Email is required.');
            valid = false;
        } else {
            const emailRegex = /^[\w._%+\-]+@[\w.\-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email.value.trim())) {
                appendError(email, 'Please enter a valid email address.');
                valid = false;
            }
        }

        const pwd = document.getElementById('newPassword');
        if (pwd.value.trim() && pwd.value.trim().length < 6) {
            appendError(pwd, 'New password must be at least 6 characters.');
            valid = false;
        }

        return valid;
    }

    function appendError(el, msg) {
        const err = document.createElement('div');
        err.className = 'field-error-msg client-error';
        err.textContent = msg;
        el.parentNode.appendChild(err);
    }
</script>
