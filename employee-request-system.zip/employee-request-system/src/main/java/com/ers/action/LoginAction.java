package com.ers.action;

import com.ers.entity.User;
import com.ers.enums.Role;
import com.ers.service.AuthService;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.struts2.interceptor.SessionAware;

import java.util.Map;

/**
 * Handles the login and logout flow.
 *
 * execute()  → called on POST /login — validates credentials, stores session, redirects by role
 * logout()   → called on GET  /logout — clears session, redirects to login
 *
 * Implements SessionAware so Struts injects the HTTP session map directly.
 * Session keys are defined as constants to avoid typos across the codebase.
 */
public class LoginAction extends ActionSupport implements SessionAware {

    private static final Logger logger = LogManager.getLogger(LoginAction.class);

    // Session attribute keys — used by AuthInterceptor and JSPs to read session data
    public static final String SESSION_USER_ID      = "userId";
    public static final String SESSION_USERNAME     = "username";
    public static final String SESSION_FULL_NAME    = "fullName";
    public static final String SESSION_ROLE         = "role";
    public static final String SESSION_DEPT_ID      = "departmentId";

    private Map<String, Object> session;

    // Form fields — Struts binds request parameters to these via getters/setters
    private String username;
    private String password;

    private final AuthService authService = new AuthService();

    /**
     * Called when the login form is submitted (POST).
     * Validates credentials, populates session, and redirects based on role.
     *
     * @return "admin", "manager", or "employee" result name (mapped in struts.xml)
     *         or INPUT if validation fails
     */
    @Override
    public String execute() {
        User user = authService.login(username, password);

        if (user == null) {
            addActionError("Invalid username or password. Please try again.");
            return INPUT;
        }

        // Store minimal user info in session — never store the full entity
        session.put(SESSION_USER_ID,   user.getId());
        session.put(SESSION_USERNAME,  user.getUsername());
        session.put(SESSION_FULL_NAME, user.getFullName());
        session.put(SESSION_ROLE,      user.getRole().name());
        session.put(SESSION_DEPT_ID,   user.getDepartmentId());

        logger.info("Session created for user: {} role: {}", user.getUsername(), user.getRole());

        // Redirect to the appropriate dashboard based on role
        if (user.getRole() == Role.ADMIN)    return "admin";
        if (user.getRole() == Role.MANAGER)  return "manager";
        return "employee";
    }

    /**
     * Called when the user clicks Logout.
     * Invalidates the session and redirects to the login page.
     *
     * @return "login" result (redirect to /login.action)
     */
    public String logout() {
        session.clear();
        logger.info("User logged out, session cleared.");
        return "login";
    }

    // --- SessionAware ---
    @Override
    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    // --- Getters and Setters for form fields ---
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
